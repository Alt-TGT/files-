const { backupIfDue } = require('../server');
backupIfDue().then(()=>process.exit(0)).catch(err=>{console.error(err);process.exit(1);});

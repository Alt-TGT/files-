const crypto = require('node:crypto');
const password = process.argv[2];
if (!password || password.length < 12) {
  console.error('Usage: node scripts/create-master-hash.js "A strong password (12+ chars)"');
  process.exit(1);
}
const salt = crypto.randomBytes(16).toString('hex');
const hash = crypto.scryptSync(password, salt, 64).toString('hex');
console.log(`${salt}:${hash}`);

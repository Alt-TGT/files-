const fs=require('node:fs');const path=require('node:path');const cp=require('node:child_process');
const root=path.join(__dirname,'..');
let failures=0;
for(const dir of ['server.js','scripts/create-master-hash.js','scripts/backup.js','scripts/validate.js',...walk(path.join(root,'public','js'))]){
  const p=path.join(root,dir); if(fs.existsSync(p)&&p.endsWith('.js')){const r=cp.spawnSync(process.execPath,['--check',p],{encoding:'utf8'});if(r.status!==0){failures++;console.error(r.stderr)}}
}
for(const p of walk(path.join(root,'public'))){ if(p.endsWith('.html')){const s=fs.readFileSync(p,'utf8');if(!/<html[ >]/i.test(s)||!/<body[ >]/i.test(s)){failures++;console.error('HTML structure problem:',p)}} }
console.log(failures?`Validation failures: ${failures}`:'Validation passed: JS syntax and HTML structure checks are clean.');
process.exit(failures?1:0);
function walk(dir){let out=[];if(!fs.existsSync(dir))return out;for(const x of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,x.name);if(x.isDirectory())out=out.concat(walk(p));else out.push(path.relative(root,p))}return out}

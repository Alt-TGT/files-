# Kaanha Bakers N Sweets — production deployment guide for a complete beginner

## What you need to buy/create

1. **A domain** — e.g. `kaanhabakers.in`.
2. **A GitHub account** — free account is enough for the repository.
3. **A Render account** — this runs the Node.js application on the public internet.
4. **A Supabase account/project** — this holds the Postgres database and uploaded media.
5. **Razorpay account** — only needed when you enable online paid orders.
6. **WhatsApp Business Cloud API setup** — needed for WhatsApp owner notifications.
7. **Email provider** — Resend is used by this build for owner email alerts.
8. **Map tile provider** — use a production provider such as MapTiler/Mapbox for meaningful traffic; the project contains an OpenStreetMap fallback for light testing.
9. **SMS provider** — Twilio is supported for phone verification before delivery orders.

## A. Put the code on GitHub

1. Sign in to GitHub.
2. Create a new repository named something like `kaanha-bakers-n-sweets`.
3. Keep it private unless you have a reason to make it public.
4. Upload the entire contents of this folder. Do NOT upload `.env` or any real API keys.
5. Push/commit the files.

## B. Create Supabase

1. Create a new Supabase project.
2. Open **SQL Editor**.
3. Copy everything from `schema.sql` and run it.
4. Create a Storage bucket named `site-media`.
5. Copy your Supabase URL and the service-role key from the project settings.
6. Never put the service-role key into frontend code or GitHub.

## C. Create your Master password

On your computer, open a terminal in the project folder and run:

    node scripts/create-master-hash.js "YOUR-STRONG-MASTER-PASSWORD"

Copy the output into `MASTER_PASSWORD_HASH` in your production environment.

## D. Deploy to Render

1. Create a Render account.
2. Choose **New → Web Service**.
3. Connect the GitHub repository.
4. Runtime: Node.
5. Build command: `npm install`.
6. Start command: `npm start`.
7. Add all variables from `.env.example` in Render's Environment section.
8. Deploy.
9. Open the temporary Render URL and test the site.

This app binds to `0.0.0.0` and uses the Render `PORT` variable, so it is suitable for a Render web service.

## E. Attach your domain

1. Open the Render service.
2. Go to the custom-domain section.
3. Add your purchased domain.
4. Render will tell you the DNS record(s) to add at your domain registrar.
5. Add the exact DNS values Render shows.
6. Wait for DNS to propagate.
7. Change `APP_ORIGIN` to your final `https://` domain.
8. Redeploy.

## F. First production setup

1. Open `/master-login.html` on the real domain.
2. Log in with the Master email/password from the environment variables.
3. In Master → Owner accounts, create the bakery owner account(s).
4. Change the initial owner password if necessary.
5. In Master → Settings, set the logo, phone, WhatsApp, email and address.
6. In Master → Content, set the homepage title/subtitle, hero background and About gallery.
7. In Master → Design, set colours, radius, width and feature switches.
8. Add real products/stock from the Owner panel.
9. Add categories and assign warehouse products to Menu/Cakes/Sweets.
10. Set shop-open and online-order settings.
11. Configure taxes/charges and delivery minimum.

## G. Razorpay

1. Start in Razorpay Test Mode.
2. Create API keys.
3. Put Key ID + Key Secret into Render environment variables.
4. Put the webhook secret into `RAZORPAY_WEBHOOK_SECRET`.
5. Configure Razorpay to call:

    https://YOUR-DOMAIN.example/api/payments/razorpay/webhook

6. Test a payment before enabling Live Mode.
7. Switch to Live credentials only after test orders are verified.

The Key Secret must never be exposed in frontend JavaScript.

## H. WhatsApp alerts

Configure Meta WhatsApp Cloud API and put the access token, phone-number ID and owner's WhatsApp number into Render.

Be aware that Meta may require approved WhatsApp message templates depending on the conversation context. The application sends an owner alert when an order is created.

## I. Email alerts

Configure your email provider and put:

- `RESEND_API_KEY`
- `EMAIL_FROM`
- `OWNER_NOTIFICATION_EMAIL`

into Render.

## J. Phone verification for delivery

Delivery accounts need a verified phone number. Configure Twilio:

- `TWILIO_ACCOUNT_SID`
- `TWILIO_AUTH_TOKEN`
- `TWILIO_FROM_NUMBER`

A logged-in customer can then request an OTP from the login page and verify the phone number before placing a delivery order.

## K. Automatic backups

Create a Render Cron Job that runs once per day with:

    npm run backup

The script checks the Master-selected backup interval and only makes a new backup when it is due. You can set the interval from Master → Global settings.

## L. Updating the site later

The normal workflow is:

1. You ask for a change.
2. The code is updated in the GitHub repository.
3. Push the change.
4. Render detects the change and deploys the new version.
5. Database/product/order data stays in Supabase.

You do not replace the database with a ZIP upload.

## Important security rules

- Do not put `.env` in GitHub.
- Do not put Razorpay Key Secret in frontend code.
- Do not put the Supabase service-role key in frontend code.
- Use a unique Master password.
- Use HTTPS in production.
- Rotate secrets if they are accidentally exposed.
- Keep the GitHub repository private.

## Current production fix before owner/master testing

1. In Supabase, open **SQL Editor** and create a blank SQL query.
2. Paste the contents of `scripts/production-fix.sql` and run it once.
3. In Render, keep `APP_ORIGIN` set to the exact live URL, e.g. `https://kaanha-bakers.onrender.com` (later replace it with the final custom domain).
4. Push the project to GitHub and wait for Render to deploy the new commit.

This release also fixes owner inventory-to-menu assignment, compact POS/new-bill behavior, 10-second order polling, homepage status dots, map links for the address, and the default branded homepage background.

# Kaanha Bakers N Sweets — Production Build

Production-oriented Node application for the Kaanha Bakers N Sweets website, customer ordering, owner operations, POS, inventory, and master administration.

## Current release highlights

- Clean mobile-first customer UI.
- Branded home welcome page with Since 2008 and default local hero artwork.
- Homepage shop/online-order indicators with separate green/red dots.
- Address links open Google Maps; phone links open the dialer.
- Loader animation is only used on the homepage initial load.
- Owner inventory can add/edit products with multiple photos, optional CP, SP, units, stock, barcode/SKU, and low-stock messaging.
- Main Menu, Cakes, and Sweets can add multiple products from the warehouse with per-product category selection.
- Compact POS with a clear **New bill** flow and barcode/name search.
- Owner order polling every 10 seconds with desktop notification support.
- Flexible online-order charges/taxes.
- Master content/media/theme/logo/notification-sound controls.
- Master-created owner accounts only.
- 20 MB media limit.
- Automatic backup support.

## Supabase production fix

Before testing Master/Owner features on a fresh or existing production database, run:

`scripts/production-fix.sql`

in the Supabase SQL Editor once. The same grants are appended to `schema.sql` for fresh projects.

## Important

- Keep all secrets in Render environment variables; never commit `.env` or real keys to GitHub.
- Rotate any service-role key that has previously been exposed.
- Use Razorpay test mode before live payments.

## Media / Instagram note

The public web fetch for the supplied Instagram account `@kaanha.bakers` was throttled during this build, so official Instagram media was not copied or misattributed. The admin panel supports replacing the logo and uploading homepage/About/product media. A local branded hero image is included as a safe default.

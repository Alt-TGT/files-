# Public menu source notes

The initial product seed was compiled from publicly visible Kaanha Bakers / Kaanha Bakers & Sweets listings on Zomato and Swiggy checked on 2026-08-22.

Sources used:
- Zomato: Kaanha Bakers & Sweets, Sagar Locality — current sweets and cake listing.
- Zomato: Kaanha Bakers & Sweets, Tili Road, near Chaitanya Hospital — current bakery/cafe/sweets listing.
- Zomato: Kaanha Bakers Cafe & Restaurant, Sagar Locality — current broader cafe/bakery/sweets listing.
- Swiggy: Kaanha Bakers Sweets Cafe and Restaurant, Sagar City — current sweets/cakes/desserts listing.

Important: third-party product photos and long descriptions are not copied into the build. Product names and publicly listed prices are used as a starting catalogue; the owner should upload the business's own authorized product photos and edit descriptions before launch.

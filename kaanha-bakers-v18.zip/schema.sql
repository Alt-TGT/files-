create extension if not exists pgcrypto;

create table if not exists profiles (
  id uuid primary key default gen_random_uuid(),
  email text unique,
  phone text unique,
  name text not null,
  password_hash text not null,
  role text not null check (role in ('customer','owner','master')),
  active boolean not null default true,
  verified_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  collections text[] not null default '{}',
  sort_order int not null default 0,
  active boolean not null default true
);

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text default '',
  price numeric(12,2) not null default 0,
  cost_price numeric(12,2),
  unit text not null default 'piece',
  stock numeric(12,3) not null default 0,
  low_stock_threshold numeric(12,3) not null default 0,
  low_stock_message text default '',
  barcode text unique,
  sku text,
  images jsonb not null default '[]'::jsonb,
  active boolean not null default true,
  bestseller boolean not null default false,
  featured boolean not null default false,
  availability_start time,
  availability_end time,
  availability_days int[] default '{0,1,2,3,4,5,6}',
  availability_message text default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists product_collections (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  collection text not null check (collection in ('menu','cakes','sweets')),
  category_id uuid references categories(id) on delete set null,
  sort_order int not null default 0,
  unique(product_id, collection)
);

create table if not exists site_settings (
  id int primary key default 1,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists content_sections (
  id uuid primary key default gen_random_uuid(),
  section_key text unique not null,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists pages (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  subtitle text default '',
  data jsonb not null default '{}'::jsonb,
  active boolean not null default true,
  sort_order int not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists media (
  id uuid primary key default gen_random_uuid(),
  url text not null,
  kind text not null check (kind in ('image','video','audio')),
  caption text default '',
  placement text default 'library',
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists charges (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  kind text not null check (kind in ('fixed','percent')),
  value numeric(12,4) not null default 0,
  enabled boolean not null default true,
  scope jsonb not null default '{"mode":"all"}'::jsonb,
  apply_to text[] not null default '{online}'
);

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  order_number bigserial unique,
  customer_id uuid references profiles(id) on delete set null,
  customer_name text not null,
  customer_phone text not null,
  customer_email text,
  fulfillment text not null check (fulfillment in ('takeaway','delivery')),
  delivery_address text,
  delivery_lat numeric(10,7),
  delivery_lng numeric(10,7),
  subtotal numeric(12,2) not null,
  discount numeric(12,2) not null default 0,
  delivery_fee numeric(12,2) not null default 0,
  charges numeric(12,2) not null default 0,
  total numeric(12,2) not null,
  payment_method text not null default 'cod',
  payment_status text not null default 'pending',
  razorpay_order_id text,
  razorpay_payment_id text,
  status text not null default 'received',
  pickup_date date,
  pickup_time time,
  status_history jsonb not null default '[]'::jsonb,
  items jsonb not null default '[]'::jsonb,
  notes text default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists pos_bills (
  id uuid primary key default gen_random_uuid(),
  bill_number bigserial unique,
  customer_name text default '',
  customer_phone text default '',
  items jsonb not null default '[]'::jsonb,
  subtotal numeric(12,2) not null default 0,
  discount numeric(12,2) not null default 0,
  charges numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0,
  status text not null default 'draft',
  created_by uuid references profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists audit_log (
  id bigserial primary key,
  actor_id uuid references profiles(id) on delete set null,
  actor_role text,
  action text not null,
  entity text,
  entity_id text,
  before_data jsonb,
  after_data jsonb,
  created_at timestamptz not null default now()
);

create table if not exists backups (
  id uuid primary key default gen_random_uuid(),
  storage_path text not null,
  created_at timestamptz not null default now(),
  size_bytes bigint default 0
);

create table if not exists otp_tokens (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references profiles(id) on delete cascade,
  channel text not null,
  token_hash text not null,
  expires_at timestamptz not null,
  attempts int not null default 0,
  created_at timestamptz not null default now()
);

insert into site_settings(id, data) values (1, jsonb_build_object(
  'brandName','Kaanha Bakers N Sweets',
  'logoUrl','/assets/kaanha-logo.png',
  'homeBackgroundUrl','/assets/home/kaanha-home-bg.jpg',
  'shopOpen',true,
  'onlineOrders',true,
  'takeawayEnabled',true,
  'deliveryEnabled',true,
  'minimumDeliveryOrder',300,
  'phone','',
  'whatsapp','',
  'email','',
  'address','',
  'instagram','',
  'city','Sagar, Madhya Pradesh',
  'theme',jsonb_build_object('primary','#8b4b2d','header','#d8c8bb','accent','#c89a63','bg','#fbf7f1','surface','#ffffff','text','#3c3c3c','muted','#756b63','radius','18px','max','1180px','heroTitle','50px','space','52px'),
  'features',jsonb_build_object('cakes',true,'sweets',true,'onlineOrdering',true,'customerAccounts',true,'pos',true,'delivery',true,'takeaway',true,'razorpay',false,'whatsappAlerts',false,'emailAlerts',false,'customerReviews',false,'customPages',true),
  'notificationSoundUrl','/assets/notification.mp3',
  'backupIntervalDays',7,
  'lastBackupAt',null
)) on conflict(id) do nothing;

insert into content_sections(section_key,data) values
('home',jsonb_build_object('title','Made for everyday celebrations.','subtitle','Fresh bakery favourites, cakes and Indian sweets from Kaanha Bakers N Sweets.','heroButton','Browse the menu.')),
('about',jsonb_build_object('title','Made fresh for the moments that matter.','text','A warm local bakery and sweets destination.' )),
('contact',jsonb_build_object('title','Come by or get in touch.'))
on conflict(section_key) do nothing;

create index if not exists products_barcode_idx on products(barcode);
create index if not exists orders_customer_idx on orders(customer_id, created_at desc);
create index if not exists orders_status_idx on orders(status, created_at desc);
create index if not exists product_collections_idx on product_collections(collection, sort_order);

-- Production REST API privileges for the server-side service_role key.
grant usage on schema public to service_role;
grant select, insert, update, delete on all tables in schema public to service_role;
grant usage, select, update on all sequences in schema public to service_role;
alter default privileges for role postgres in schema public grant select, insert, update, delete on tables to service_role;
alter default privileges for role postgres in schema public grant usage, select, update on sequences to service_role;

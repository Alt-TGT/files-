import {press} from 'https://cdn.jsdelivr.net/npm/motion@13.2.0/+esm';
import {api,loadPublicSettings,addCart,setCart,getCart,money,updateCartBadge,toast,initMobileNav,cartCount,esc} from './common.js';
const state={settings:null};
for(const [k,v] of Object.entries({primary:'#8b4b2d',header:'#d8c8bb',accent:'#c89a63',bg:'#fbf7f1',surface:'#ffffff',text:'#3c3c3c',muted:'#756b63',radius:'18px',max:'1180px',heroTitle:'50px',space:'52px'}))document.documentElement.style.setProperty(`--${k}`,v);
const SAFE_SETTINGS={brandName:'Kaanha Bakers N Sweets',logoUrl:'/assets/kaanha-logo.png',homeBackgroundUrl:'/assets/home/kaanha-home-bg.jpg',shopOpen:true,onlineOrders:true,deliveryEnabled:true,takeawayEnabled:true,minimumDeliveryOrder:300,phone:'',whatsapp:'',email:'',address:'',instagram:'',theme:{primary:'#8b4b2d',header:'#d8c8bb',accent:'#c89a63',bg:'#fbf7f1',surface:'#ffffff',text:'#3c3c3c',muted:'#756b63',radius:'18px',max:'1180px',heroTitle:'50px',space:'52px'},features:{},notificationSoundUrl:'/assets/notification.mp3'};

function bindPressButtons(root=document){
  root.querySelectorAll('[data-add]').forEach(button=>{
    if(button.dataset.pressReady==='1')return;
    button.dataset.pressReady='1';
    press(button, element=>{
      element.classList.add('is-pressed');
      return ()=>element.classList.remove('is-pressed');
    });
  });
}

function updateFoldText(el,text){
  if(!el)return;
  const value=String(text||'');
  if(el.dataset.foldReady!=='1'){el.textContent=value;return;}
  el.setAttribute('aria-label',value);
  const pieces=[...el.querySelectorAll('.fold-text-piece')];
  [...value].forEach((ch,i)=>{if(pieces[i])pieces[i].textContent=ch===' '?'\u00a0':ch});
  if(pieces.length>value.length){for(let i=value.length;i<pieces.length;i++)pieces[i].parentElement?.remove();}
  if(pieces.length<value.length){
    const frag=document.createDocumentFragment();
    for(let i=pieces.length;i<value.length;i++){
      const seg=document.createElement('span');seg.className='fold-text-segment';
      const piece=document.createElement('span');piece.className='fold-text-piece';
      piece.style.setProperty('--fold-delay',`${i*0.028}s`);piece.textContent=value[i]===' '?'\u00a0':value[i];seg.appendChild(piece);frag.appendChild(seg);
    }
    el.appendChild(frag);
  }
}

function setupHeroAnimation(){
  const hero=document.querySelector('[data-hero]');
  if(!hero)return;
  if(hero.dataset.entranceStarted==='1')return;
  hero.dataset.entranceStarted='1';
  document.body.classList.add('home-animation-ready');
  const foldTargets=[hero.querySelector('.hero-fold-brand'),hero.querySelector('.hero-fold-title')].filter(Boolean);
  foldTargets.forEach((el)=>{
    if(el.dataset.foldReady==='1')return;
    const text=el.textContent;
    el.dataset.foldReady='1';
    el.setAttribute('aria-label',text);
    const frag=document.createDocumentFragment();
    [...text].forEach((ch,i)=>{
      const seg=document.createElement('span');
      seg.className='fold-text-segment';
      const piece=document.createElement('span');
      piece.className='fold-text-piece';
      piece.style.setProperty('--fold-delay',`${i*0.028}s`);
      piece.textContent=ch===' '? '\u00a0':ch;
      seg.appendChild(piece); frag.appendChild(seg);
    });
    el.textContent=''; el.appendChild(frag);
  });
  hero.querySelectorAll('.hero-shiny').forEach(el=>el.classList.add('shiny-text-live'));
  hero.querySelector('.hero-copy')?.classList.add('hero-copy-enter');
  hero.querySelector('.hero-fold-brand')?.classList.add('fold-play');
  hero.querySelector('.hero-fold-title')?.classList.add('fold-play');
  hero.querySelector('.hero-subtitle')?.classList.add('hero-subtitle-play');
  hero.querySelector('.hero-actions')?.classList.add('hero-actions-play');
  hero.querySelector('.hero-carousel-window')?.classList.add('hero-carousel-play');
  document.querySelector('.home-lime-reveal')?.classList.add('home-section-play');
  setupDockNavigation();
}

function setupDockNavigation(){
  const nav=document.querySelector('.nav-links');
  if(!nav || nav.dataset.dockReady==='1')return;
  nav.dataset.dockReady='1';
  if(!window.matchMedia('(min-width:961px)').matches)return;
  const links=[...nav.querySelectorAll('a')];
  links.forEach(a=>a.dataset.dockItem='1');
  const current=links.find(a=>new URL(a.href,location.href).pathname===location.pathname);
  current?.classList.add('dock-active');
  const distance=150;
  const maxScale=1.12;
  const update=(clientX)=>{
    links.forEach(a=>{
      const r=a.getBoundingClientRect();
      const center=r.left+r.width/2;
      const d=Math.abs(clientX-center);
      const t=Math.max(0,1-d/distance);
      const scale=1+(maxScale-1)*t;
      a.style.setProperty('--dock-scale',scale.toFixed(3));
      a.style.setProperty('--dock-lift',`${(-3*t).toFixed(2)}px`);
    });
  };
  nav.addEventListener('pointermove',e=>update(e.clientX));
  nav.addEventListener('pointerleave',()=>{
    links.forEach(a=>{
      a.style.setProperty('--dock-scale','1');
      a.style.setProperty('--dock-lift','0px');
    });
  });
  links.forEach(a=>{
    a.addEventListener('click',()=>{
      links.forEach(x=>x.classList.remove('dock-active'));
      a.classList.add('dock-active');
    });
  });
}

function startMorphSlider(box){
  if(!box||box.dataset.morphReady==='1')return;
  box.dataset.morphReady='1';
  const imgs=[...box.querySelectorAll('.hero-slide')];
  if(imgs.length<=1)return;
  box.innerHTML='';
  const viewport=document.createElement('div');
  viewport.className='morph-slider-viewport';
  const layerA=document.createElement('img'); layerA.className='morph-slide active';
  const layerB=document.createElement('img'); layerB.className='morph-slide';
  viewport.append(layerA,layerB);
  box.appendChild(viewport);
  const dots=document.createElement('div'); dots.className='morph-slider-indicators';
  imgs.forEach((img,i)=>{const d=document.createElement('button');d.type='button';d.className='morph-slider-indicator'+(i===0?' active':'');d.setAttribute('aria-label',`Go to slide ${i+1}`);d.onclick=()=>go(i,true);dots.appendChild(d)});
  box.appendChild(dots);
  let index=0, timer=null, morphing=false, hover=false;
  const apply=(el,src,caption='')=>{el.src=src;el.alt=caption||''};
  apply(layerA,imgs[0].src,imgs[0].alt);
  const go=(next,animate)=>{
    next=(next+imgs.length)%imgs.length;
    if(next===index && !animate)return;
    const incoming=layerA.classList.contains('active')?layerB:layerA;
    const outgoing=incoming===layerA?layerB:layerA;
    apply(incoming,imgs[next].src,imgs[next].alt);
    incoming.classList.remove('morph-instant'); outgoing.classList.remove('morph-out');
    if(animate){
      morphing=true;
      incoming.classList.add('morph-in'); outgoing.classList.add('morph-out');
      const done=()=>{incoming.removeEventListener('transitionend',done);incoming.classList.add('active');outgoing.classList.remove('active');incoming.classList.remove('morph-in');outgoing.classList.remove('morph-out');morphing=false};
      incoming.addEventListener('transitionend',done,{once:true});
      setTimeout(()=>{if(morphing)done()},700);
    }else{incoming.classList.add('active');outgoing.classList.remove('active')}
    index=next;
    [...dots.children].forEach((d,i)=>d.classList.toggle('active',i===index));
  };
  const reset=()=>{clearInterval(timer);timer=setInterval(()=>{if(!hover&&!morphing)go(index+1,true)},3400)};
  viewport.addEventListener('mouseenter',()=>{hover=true;clearInterval(timer)});
  viewport.addEventListener('mouseleave',()=>{hover=false;reset()});
  viewport.addEventListener('touchstart',()=>{clearInterval(timer)},{passive:true});
  viewport.addEventListener('touchend',reset,{passive:true});
  requestAnimationFrame(()=>go(0,false));
  reset();
}

function ensureAnimatedTotal(root){
  const el=root.querySelector('#total');
  if(!el)return null;
  if(!el.querySelector('.kaanha-counter')){
    el.innerHTML='<span class="kaanha-total-currency">₹</span><span class="kaanha-counter" aria-live="polite"></span>';
  }
  return el.querySelector('.kaanha-counter');
}
function setAnimatedTotal(root,value){
  const counter=ensureAnimatedTotal(root);
  if(!counter)return;
  const normalized=Number.isFinite(Number(value))?Number(value):0;
  const formatted=normalized.toFixed(2);
  let state=counter.__counterState;
  if(!state){state={chars:[],value:formatted};counter.__counterState=state;counter.innerHTML='';}
  if(state.value===formatted && counter.children.length)return;
  const parts=formatted.split('');
  while(counter.children.length<parts.length){
    const holder=document.createElement('span'); holder.className='kaanha-counter-char';
    counter.appendChild(holder);
  }
  while(counter.children.length>parts.length)counter.lastElementChild.remove();
  [...parts].forEach((ch,i)=>{
    const holder=counter.children[i];
    if(ch==='.'){
      holder.className='kaanha-counter-decimal'; holder.textContent='.'; return;
    }
    holder.className='kaanha-counter-char';
    let track=holder.querySelector('.kaanha-counter-track');
    if(!track){
      track=document.createElement('span'); track.className='kaanha-counter-track';
      for(let n=0;n<10;n++){const d=document.createElement('span');d.textContent=String(n);track.appendChild(d)}
      holder.replaceChildren(track);
    }
    track.style.setProperty('--counter-y',String(Number(ch)));
  });
  state.value=formatted;
}

function startHeroCarousel(box){
  if(!box||box.dataset.carouselReady==='1')return;
  box.dataset.carouselReady='1';
  const els=[...box.querySelectorAll('.hero-slide')];
  if(els.length<=1)return;

  const viewport=document.createElement('div');
  viewport.className='hero-carousel-viewport';
  const track=document.createElement('div');
  track.className='hero-carousel-track';
  viewport.appendChild(track);

  const makeSlide=(img,index,clone=false)=>{
    const item=document.createElement('div');
    item.className='hero-carousel-item'+(clone?' is-clone':'');
    item.dataset.index=String(index);
    item.appendChild(img);
    return item;
  };

  const originals=els.map((img,index)=>makeSlide(img,index));
  const firstClone=originals[0].cloneNode(true); firstClone.classList.add('is-clone');
  const lastClone=originals[originals.length-1].cloneNode(true); lastClone.classList.add('is-clone');
  track.appendChild(lastClone);
  originals.forEach(item=>track.appendChild(item));
  track.appendChild(firstClone);

  box.replaceChildren(viewport);

  const indicators=document.createElement('div');
  indicators.className='hero-carousel-indicators';
  els.forEach((_,i)=>{
    const dot=document.createElement('button');
    dot.type='button';
    dot.className='hero-carousel-indicator'+(i===0?' active':'');
    dot.setAttribute('aria-label',`Go to slide ${i+1}`);
    dot.addEventListener('click',()=>goTo(i+1,true));
    indicators.appendChild(dot);
  });
  box.appendChild(indicators);

  let pos=1;
  let timer=null;
  let dragging=false;
  let startX=0;
  let deltaX=0;
  let width=0;

  const dots=[...indicators.children];
  const setTrack=(animate=true)=>{
    width=viewport.clientWidth||box.clientWidth||1;
    track.style.transition=animate?'transform .52s cubic-bezier(.22,.75,.18,1)':'none';
    track.style.transform=`translate3d(${-pos*width}px,0,0)`;
    const active=((pos-1)%els.length+els.length)%els.length;
    dots.forEach((d,i)=>d.classList.toggle('active',i===active));
  };

  const goTo=(next,animate=true)=>{
    pos=next;
    setTrack(animate);
  };

  const finishSnap=()=>{
    if(pos===els.length+1){pos=1;setTrack(false);}
    if(pos===0){pos=els.length;setTrack(false);}
  };

  track.addEventListener('transitionend',finishSnap);
  const resetTimer=()=>{
    clearInterval(timer);
    timer=setInterval(()=>goTo(pos+1,true),3200);
  };
  const stopTimer=()=>clearInterval(timer);

  const pointerDown=e=>{
    dragging=true;startX=e.clientX;deltaX=0;stopTimer();track.style.transition='none';
    viewport.setPointerCapture?.(e.pointerId);
  };
  const pointerMove=e=>{
    if(!dragging)return;
    deltaX=e.clientX-startX;
    track.style.transform=`translate3d(${(-pos*width)+deltaX}px,0,0)`;
  };
  const pointerUp=e=>{
    if(!dragging)return;
    dragging=false;
    const threshold=Math.max(40,width*0.16);
    if(Math.abs(deltaX)>threshold)goTo(pos+(deltaX<0?1:-1),true);
    else setTrack(true);
    resetTimer();
    viewport.releasePointerCapture?.(e.pointerId);
  };

  viewport.addEventListener('pointerdown',pointerDown);
  viewport.addEventListener('pointermove',pointerMove);
  viewport.addEventListener('pointerup',pointerUp);
  viewport.addEventListener('pointercancel',pointerUp);
  viewport.addEventListener('mouseenter',stopTimer);
  viewport.addEventListener('mouseleave',()=>{if(!dragging)resetTimer()});
  viewport.addEventListener('touchstart',e=>{if(e.touches[0])pointerDown(e.touches[0])},{passive:true});
  viewport.addEventListener('touchmove',e=>{if(e.touches[0])pointerMove(e.touches[0])},{passive:true});
  viewport.addEventListener('touchend',pointerUp,{passive:true});

  const onResize=()=>setTrack(false);
  window.addEventListener('resize',onResize);
  box._heroCarouselCleanup=()=>{stopTimer();window.removeEventListener('resize',onResize)};
  requestAnimationFrame(()=>setTrack(false));
  resetTimer();
}

function hideLoader(delay=650){const load=document.querySelector('.loading-screen');if(!load||load.dataset.exiting==='1')return;window.clearTimeout(window.__kaanhaLoaderTimer);window.__kaanhaLoaderTimer=window.setTimeout(()=>{load.dataset.exiting='1';load.style.animation='none';const img=load.querySelector('.loading-logo');const target=document.querySelector('.site-header [data-logo]');if(!img||!target){load.classList.add('hide');return}const a=img.getBoundingClientRect(),b=target.getBoundingClientRect();const clone=img.cloneNode(true);clone.className='loading-logo-flight';clone.style.left=`${a.left}px`;clone.style.top=`${a.top}px`;clone.style.width=`${a.width}px`;clone.style.height=`${a.height}px`;clone.style.borderRadius=getComputedStyle(target).borderRadius||'12px';document.body.appendChild(clone);target.style.opacity='0';requestAnimationFrame(()=>{const sx=b.width/a.width,sy=b.height/a.height;const tx=b.left-a.left,ty=b.top-a.top;clone.style.transform=`translate(${tx}px,${ty}px) scale(${sx},${sy})`;load.classList.add('hide')});window.setTimeout(()=>{target.style.opacity='';clone.remove();load.remove()},760)},delay)}
async function boot(){initMobileNav();setupDockNavigation();setupMenuCommandPalette();updateCartBadge();const page=document.body.dataset.page;if(page==='home'){setupHeroAnimation();hideLoader(0);window.__kaanhaLoaderFailsafe=setTimeout(()=>hideLoader(0),4500)}let settingsPromise=loadPublicSettings().catch(err=>{console.error('Public settings unavailable; using safe defaults.',err);return SAFE_SETTINGS});try{state.settings=await Promise.race([settingsPromise,new Promise(r=>setTimeout(()=>r(SAFE_SETTINGS),1200))])}catch{state.settings=SAFE_SETTINGS}applyBrand(state.settings);applyStatus(state.settings);settingsPromise.then(s=>{if(s&&s!==state.settings){state.settings=s;applyBrand(s);applyStatus(s)}}).catch(()=>{});try{if(page==='home')await home();if(page==='catalog')await catalog();if(page==='product')await product();if(page==='order')await order();if(page==='account')await account();if(page==='login')await login();if(page==='content')await content();if(page==='category')await category();setupStaggerReveal()}catch(err){console.error('Page data failed to load.',err);const target=document.querySelector('[data-page-error]');if(target)target.textContent='Some live information could not be loaded. Please refresh in a moment.'}}
function applyBrand(s){s=s||SAFE_SETTINGS;document.querySelectorAll('[data-brand]').forEach(x=>x.textContent=s.brandName||SAFE_SETTINGS.brandName);document.querySelectorAll('[data-logo]').forEach(x=>x.src=s.logoUrl||SAFE_SETTINGS.logoUrl);if(s.theme){for(const [k,v] of Object.entries(s.theme))document.documentElement.style.setProperty(`--${k}`,v);let cs=document.getElementById('custom-brand-css');if(!cs){cs=document.createElement('style');cs.id='custom-brand-css';document.head.appendChild(cs)}cs.textContent=s.theme.customCss||''}const load=document.querySelector('.loading-screen');if(load){const img=load.querySelector('img');if(img)img.src=s.logoUrl||SAFE_SETTINGS.logoUrl}if(document.body.dataset.page==='home')hideLoader(0)}
function applyStatus(s){const mapUrl=s.address?`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(s.address)}`:'#';document.querySelectorAll('[data-footer-address], [data-contact-address]').forEach(x=>{x.textContent=s.address||'Find us on Maps';if(x.tagName==='A')x.href=mapUrl});document.querySelectorAll('[data-footer-call]').forEach(x=>{x.href=s.phone?'tel:'+s.phone:'#';x.textContent=s.phone||'Call the shop'});document.querySelectorAll('[data-footer-wa]').forEach(x=>{x.href=s.whatsapp?'https://wa.me/'+String(s.whatsapp).replace(/[^0-9]/g,''):'#'});document.querySelectorAll('[data-footer-ig]').forEach(x=>{x.href=s.instagram||'https://www.instagram.com/kaanha.bakers/';});document.querySelectorAll('[data-call-link]').forEach(x=>x.href=s.phone?'tel:'+s.phone:'#');document.querySelectorAll('[data-email-link]').forEach(x=>x.href=s.email?'mailto:'+s.email:'#');document.querySelectorAll('[data-wa-link]').forEach(x=>x.href=s.whatsapp?'https://wa.me/'+String(s.whatsapp).replace(/[^0-9]/g,''):'#');document.querySelectorAll('[data-store-status]').forEach(x=>x.textContent=s.shopOpen?'Open now':'Closed now');document.querySelectorAll('[data-order-status]').forEach(x=>x.textContent=s.onlineOrders?'Online orders on':'Online orders paused');document.querySelectorAll('[data-store-dot]').forEach(x=>x.classList.toggle('off',!s.shopOpen));document.querySelectorAll('[data-order-dot]').forEach(x=>x.classList.toggle('off',!s.onlineOrders))}

function addProductToCart(p,qty,button){
  addCart(p,qty);
  animateAddToBasket(button,p);
  toast(`${p.name} added to cart.`);
}

function animateAddToBasket(button,product){
  const cartTarget=document.querySelector('.nav-actions a[href="/order.html"]');
  if(!button||!cartTarget)return;
  const br=button.getBoundingClientRect();
  const cr=cartTarget.getBoundingClientRect();
  const fly=document.createElement('div');
  fly.className='basket-flyer';
  fly.textContent='🛒';
  fly.style.left=`${br.left+br.width/2-14}px`;
  fly.style.top=`${br.top+br.height/2-14}px`;
  document.body.appendChild(fly);
  const dx=cr.left+cr.width/2-(br.left+br.width/2);
  const dy=cr.top+cr.height/2-(br.top+br.height/2);
  requestAnimationFrame(()=>{
    fly.style.transform=`translate(${dx}px,${dy}px) scale(.55) rotate(10deg)`;
    fly.style.opacity='0';
  });
  cartTarget.classList.remove('cart-basket-pulse');
  void cartTarget.offsetWidth;
  cartTarget.classList.add('cart-basket-pulse');
  setTimeout(()=>fly.remove(),620);
}

function setupHomeScrollReveal(){
  const target=document.querySelector('.home-lime-reveal');
  if(!target||target.dataset.scrollRevealReady==='1')return;
  target.dataset.scrollRevealReady='1';
  target.classList.add('home-scroll-reveal');
  const io=new IntersectionObserver(entries=>{
    entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-visible');io.unobserve(e.target)}});
  },{threshold:.16});
  io.observe(target);
}

function setupMenuCommandPalette(){const input=document.querySelector('#menuSearch');if(!input||input.dataset.commandReady==='1')return;input.dataset.commandReady='1';document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();input.focus();input.select()}})}

function setupStaggerReveal(){
  if(document.body.dataset.page==='home')return;
  const items=[...document.querySelectorAll('.section-head,.section > .container > .grid > .card,.section > .container > .peek-row > .card,.contact-panel,.row-item,.order-status-steps')];
  items.forEach((el,i)=>{
    if(el.dataset.staggerReady==='1')return;
    el.dataset.staggerReady='1';
    el.classList.add('stagger-reveal-item');
    el.style.setProperty('--stagger-delay',`${Math.min(i,14)*45}ms`);
  });
  if(!items.length)return;
  const io=new IntersectionObserver(entries=>{
    entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('stagger-visible');io.unobserve(e.target)}});
  },{threshold:.08});
  items.forEach(el=>io.observe(el));
}

function applyBorderGlow(root=document){
  root.querySelectorAll('.home-glow-card').forEach(cardEl=>{
    if(cardEl.dataset.glowReady==='1')return;
    cardEl.dataset.glowReady='1';
    cardEl.addEventListener('pointermove',e=>{
      const r=cardEl.getBoundingClientRect();
      const x=e.clientX-r.left, y=e.clientY-r.top;
      const edge=Math.min(x,y,r.width-x,r.height-y);
      const proximity=Math.max(0,1-edge/60);
      const angle=(Math.atan2(y-r.height/2,x-r.width/2)*180/Math.PI+90+360)%360;
      cardEl.style.setProperty('--edge-proximity',proximity.toFixed(3));
      cardEl.style.setProperty('--cursor-angle',`${angle.toFixed(1)}deg`);
    });
    cardEl.addEventListener('pointerleave',()=>cardEl.style.setProperty('--edge-proximity','0'));
  });
}

async function home(){const h=document.querySelector('[data-home-title]');const p=document.querySelector('[data-home-subtitle]');const c=await api('/api/public/content?key=home');if(h)updateFoldText(h,c.data.title||'Made for everyday celebrations.');if(p)p.textContent=c.data.subtitle||'';const hero=document.querySelector('[data-hero]');if(hero&&state.settings.homeBackgroundUrl){hero.style.backgroundImage=`url(${state.settings.homeBackgroundUrl})`;hero.classList.add('has-bg');if(!hero.querySelector('.hero-overlay'))hero.insertAdjacentHTML('afterbegin','<div class="hero-overlay"></div>')}const slides=Array.isArray(c.data.homeSlides)&&c.data.homeSlides.length?c.data.homeSlides:[{url:'/assets/home/outlet-1.jpg',caption:'Our outlet'},{url:'/assets/home/outlet-2.jpg',caption:'A warm place for celebrations'},{url:'/assets/home/outlet-3.jpg',caption:'Freshly served'}];const box=hero?.querySelector('[data-home-slides]');if(box){box.innerHTML=slides.slice(0,3).map((x,i)=>`<img class="hero-slide ${i===0?'active':''}" src="${esc(x.url)}" alt="${esc(x.caption||'')}">`).join('');startMorphSlider(box)}const items=await api('/api/public/products?collection=menu&bestseller=true');const row=document.querySelector('[data-bestseller-row]');if(row)row.innerHTML=items.products.slice(0,6).map(homeCard).join('');const fresh=await api('/api/public/products?collection=menu&featured=true');const fr=document.querySelector('[data-fresh-grid]');if(fr)fr.innerHTML=fresh.products.slice(0,4).map(homeCard).join('');applyBorderGlow(document);setupHomeScrollReveal();setupHeroAnimation()}
function homeCard(p){const img=p.images?.[0]?.url||'/assets/placeholder.svg';const stock=Number(p.stock||0);const out=stock<=0;const threshold=Number(p.low_stock_threshold||0);const low=!out&&threshold>0&&stock<=threshold;const message=low?(p.low_stock_message||`Only ${stock} left`):(out?(p.low_stock_message||'Available tomorrow'):'');return `<article class="peek-card home-glow-card">${`<a class="home-product-link" href="/product.html?id=${p.id}" aria-label="View ${esc(p.name)}">`+`<img src="${img}" alt="${esc(p.name)}"></a>`}<div class="card-body"><h3>${esc(p.name)}</h3><p>${esc(p.description||'Freshly made in store')}</p>${out?`<div class="stock-message stock-message--out"><span class="stock-badge stock-badge--out">Out of stock</span>${message?`<span>${esc(message)}</span>`:''}</div>`:low?`<div class="stock-message stock-message--low"><span class="stock-badge stock-badge--low">Only few left</span>${p.low_stock_message&&p.low_stock_message!=='Only few left'?`<span>${esc(p.low_stock_message)}</span>`:''}</div>`:''}<div class="price-row"><span class="price">${money(p.price)} / ${esc(p.unit)}</span>${p.bestseller?'<span class="small-muted">Bestseller</span>':''}</div><a class="arrow-link" href="/product.html?id=${p.id}">View item <span aria-hidden="true">→</span></a></div></article>`}
function card(p){const img=p.images?.[0]?.url||'/assets/placeholder.svg';const stock=Number(p.stock||0);const out=stock<=0;const threshold=Number(p.low_stock_threshold||0);const low=!out&&threshold>0&&stock<=threshold;const message=low?(p.low_stock_message||`Only ${stock} left`):(out?(p.low_stock_message||'Available tomorrow'):'');return `<article class="card"><a href="/product.html?id=${p.id}"><img src="${img}" alt="${esc(p.name)}"></a><div class="card-body"><h3>${esc(p.name)}</h3><p>${esc(p.description||'Freshly made in store')}</p>${out?`<div class="stock-message stock-message--out"><span class="stock-badge stock-badge--out">Out of stock</span>${message?`<span>${esc(message)}</span>`:''}</div>`:low?`<div class="stock-message stock-message--low"><span class="stock-badge stock-badge--low">Only few left</span>${p.low_stock_message&&p.low_stock_message!=='Only few left'?`<span>${esc(p.low_stock_message)}</span>`:''}</div>`:''}<div class="price-row"><span class="price">${money(p.price)} / ${esc(p.unit)}</span>${p.bestseller?'<span class="small-muted">Bestseller</span>':''}</div><div style="margin-top:10px"><button class="btn small" ${out?'disabled':''} data-add="${p.id}" ${out?'style="opacity:.55"':''}>${out?'Sold out':'Add'}</button></div></div></article>`}

async function category(){const q=new URLSearchParams(location.search);const collection=q.get('collection')||'menu';const cat=q.get('cat')||'';const r=await api(`/api/public/products?collection=${collection}`);const list=r.products.filter(p=>(p.category_name||'Other')===cat);document.querySelector('[data-category-title]').textContent=cat||'Category';document.querySelector('[data-category-grid]').innerHTML=list.map(card).join('');document.querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>{const p=list.find(x=>x.id===b.dataset.add);if(p){addProductToCart(p,1,b)}});bindPressButtons()}
async function catalog(){
  const collection=document.body.dataset.collection||'menu';
  const items=await api(`/api/public/products?collection=${collection}`);
  const cats=[...new Set(items.products.map(x=>x.category_name||'Other').filter(Boolean))];
  const f=document.querySelector('[data-filters]'),sort=document.querySelector('[data-sort]'),g=document.querySelector('[data-grid]'),search=document.querySelector('#menuSearch');
  if(f)f.innerHTML=['All',...cats].map(c=>`<button class="chip" data-filter="${esc(c)}">${esc(c)}</button>`).join('');
  let activeCategory='All',query='';
  const bind=(list,root)=>{root.querySelectorAll('[data-add]').forEach(btn=>btn.onclick=()=>{const p=list.find(x=>x.id===btn.dataset.add);if(p)addProductToCart(p,1,btn)});bindPressButtons(root);applyBorderGlow(root);};
  const filterProducts=()=>items.products.filter(p=>{const cat=(p.category_name||'Other');const matchesCategory=activeCategory==='All'||cat===activeCategory;const q=query.trim().toLowerCase();const hay=[p.name,p.description,p.category_name,p.sku,p.barcode].filter(Boolean).join(' ').toLowerCase();return matchesCategory&&(!q||hay.includes(q))});
  const renderFlat=(list)=>{g.className='grid';g.innerHTML=list.map(card).join('')||'<div class="notice">No products match your search.</div>';bind(list,g)};
  const renderMenuSections=()=>{
    const source=filterProducts();
    g.className='';g.innerHTML='';
    const menuCats=(activeCategory==='All'?cats:[activeCategory]).filter(Boolean);
    for(const c of menuCats){
      const list=source.filter(p=>(p.category_name||'Other')===c);
      if(!list.length)continue;
      const visible=query?list:list.slice(0,5);
      const more=!query&&list.length>5;
      const sec=document.createElement('section');
      sec.className='section menu-category-section';sec.style.padding='0 0 30px';
      const moreCard=more?`<a class="peek-more" href="/category.html?collection=menu&cat=${encodeURIComponent(c)}"><span>See more</span><small>${list.length-5} more</small></a>`:'';
      sec.innerHTML=`<div class="section-head"><div><h2>${esc(c)}</h2><p>${list.length} items</p></div></div><div class="peek-row">${visible.map(card).join('')}${moreCard}</div>`;
      g.appendChild(sec);bind(list,sec);
    }
    if(!g.children.length)g.innerHTML='<div class="notice">No products match your search.</div>';
  };
  const render=()=>{const arr=filterProducts();if(collection==='menu'&&!sort?.value?.startsWith('price')&&!sort?.value?.includes('name'))renderMenuSections();else renderFlat(arr)};
  f?.addEventListener('click',e=>{const b=e.target.closest('[data-filter]');if(!b)return;f.querySelectorAll('.chip').forEach(x=>x.classList.remove('active'));b.classList.add('active');activeCategory=b.dataset.filter;render()});
  search?.addEventListener('input',e=>{query=e.target.value;render()});
  f?.querySelector('.chip')?.classList.add('active');
  sort?.addEventListener('change',()=>{if(collection==='menu'&&sort.value==='recommended')render();else{let arr=filterProducts();const v=sort.value;if(v==='price-low')arr.sort((a,b)=>a.price-b.price);if(v==='price-high')arr.sort((a,b)=>b.price-a.price);if(v==='name')arr.sort((a,b)=>a.name.localeCompare(b.name));renderFlat(arr)}});
  render();
}

async function product(){const id=new URLSearchParams(location.search).get('id');const r=await api(`/api/public/product/${id}`);const p=r.product;document.querySelector('[data-product]').innerHTML=`<div class="contact-grid"><div><img src="${p.images?.[0]?.url||'/assets/placeholder.svg'}" style="width:100%;border-radius:24px;aspect-ratio:1/1;object-fit:cover"></div><div class="contact-panel"><div class="eyebrow">${esc(p.category_name||'Kaanha')}</div><h1 style="font-family:Georgia,serif;font-size:42px;line-height:1.05;margin:8px 0">${esc(p.name)}</h1><p class="small-muted">${esc(p.description)}</p><div style="font-size:24px;font-weight:900;margin:16px 0">${money(p.price)} / ${esc(p.unit)}</div><div class="form"><label class="label">Quantity</label><input class="input" id="pqty" type="${['piece','pack'].includes(p.unit)?'number':'number'}" min="${['piece','pack'].includes(p.unit)?1:.01}" step="${['piece','pack'].includes(p.unit)?1:.25}" value="1"><button class="btn" id="addp">Add to cart</button></div></div></div>`;const addButton=document.querySelector('#addp');press(addButton, element=>{element.classList.add('is-pressed');return ()=>element.classList.remove('is-pressed')});addButton.onclick=()=>{const q=Number(document.querySelector('#pqty').value);if(!q)return toast('Enter a quantity.','error');addProductToCart(p,q,addButton)}}
async function order(){
  const cart=getCart();
  const root=document.querySelector('[data-order-root]');
  if(!cart.length){root.innerHTML='<div class="notice error">Your cart is empty. Go back to the menu and add something first.</div>';return}
  const me=await api('/api/auth/me').catch(()=>null);
  const s=state.settings;
  root.innerHTML=`<div class="cart-layout"><form class="form contact-panel" id="checkout"><h2 style="font-family:Georgia,serif">Checkout</h2><label class="label">Name *</label><input class="input" name="name" required><label class="label">Phone *</label><input class="input" name="phone" required inputmode="tel"><label class="label">Email (optional)</label><input class="input" name="email" type="email"><div class="form"><label class="label">Fulfilment</label><select class="select" name="fulfillment" id="fulfillment"><option value="takeaway">Takeaway</option><option value="delivery" ${s.deliveryEnabled?'':'disabled'}>Delivery</option></select></div><div id="deliveryBox" class="form hidden"><div class="notice">Delivery minimum: ${money(s.minimumDeliveryOrder)}. Sign in is required for delivery.</div><a class="btn secondary" href="/customer-login.html?next=/order.html">Sign in for delivery</a><div id="mapBox" class="map-box"></div><input type="hidden" name="lat" id="lat"><input type="hidden" name="lng" id="lng"><textarea class="textarea" name="address" placeholder="Delivery address details"></textarea></div><div class="notice">Orders are placed for today only. For advance orders, please call the shop.</div><label class="label">Payment</label><select class="select" name="paymentMethod"><option value="cod">Pay at shop / cash on delivery</option>${state.settings.paymentOnline?`<option value="razorpay">Pay online with Razorpay</option>`:`<option value="razorpay" disabled>Online payment not configured</option>`}</select><label class="label">Notes</label><textarea class="textarea" name="notes"></textarea><button class="btn" type="submit">Place order</button><div id="orderMsg"></div></form><aside class="summary"><h3>Order summary</h3><div id="summaryItems"></div><div class="summary-row"><span>Subtotal</span><strong id="subtotal"></strong></div><div id="chargeRows"></div><div class="summary-total"><span>Total</span><span id="total"></span></div><div class="cart-suggestions" id="cartSuggestions"><div class="suggestions-heading">You may also like</div><div class="suggestions-list" id="suggestionsList"></div></div></aside></div>`;
  const summaryItems=document.querySelector('#summaryItems');
  const renderItems=()=>{summaryItems.innerHTML=cart.map((x,i)=>`<div class="summary-row" style="align-items:center"><span style="flex:1">${esc(x.name)}<br><span class="small-muted">${money(x.price)} / ${esc(x.unit)}</span></span><span class="qty"><button type="button" data-qidx="${i}" data-dir="-1">−</button>${['piece','pack'].includes(x.unit)?`<strong>${x.qty}</strong>`:`<input class="input" style="width:85px;padding:7px" type="number" step="0.25" min="0.01" value="${x.qty}" data-qinput="${i}">`}<button type="button" data-qidx="${i}" data-dir="1">+</button></span></div>`).join('');
    summaryItems.querySelectorAll('[data-qidx]').forEach(b=>b.onclick=()=>{const i=Number(b.dataset.qidx),dir=Number(b.dataset.dir),unit=cart[i].unit;let q=Number(cart[i].qty)+dir;if(['piece','pack'].includes(unit))q=Math.max(1,Math.round(q));else q=Math.max(.01,Math.round(q*4)/4);cart[i].qty=q;setCart(cart);renderItems();calc()});
    summaryItems.querySelectorAll('[data-qinput]').forEach(i=>i.onchange=()=>{const idx=Number(i.dataset.qinput),q=Number(i.value);if(q>0){cart[idx].qty=q;setCart(cart);renderItems();calc()}});
  };
  const calc=async()=>{const subtotal=cart.reduce((sum,x)=>sum+Number(x.price)*Number(x.qty),0);document.querySelector('#subtotal').textContent=money(subtotal);const fulfillment=document.querySelector('#fulfillment').value;const ch=await api(`/api/public/charges?fulfillment=${fulfillment}`);let charges=0;for(const c of ch.charges||[])charges+=c.kind==='percent'?subtotal*Number(c.value)/100:Number(c.value);const delivery=fulfillment==='delivery'?Number(ch.deliveryFee||0):0;setAnimatedTotal(root,subtotal+charges+delivery);document.querySelector('#chargeRows').innerHTML=`${(ch.charges||[]).map(c=>`<div class="summary-row"><span>${esc(c.name)}</span><strong>${c.kind==='percent'?(Number(c.value).toFixed(2)+'%'):money(c.value)}</strong></div>`).join('')}${delivery?`<div class="summary-row"><span>Delivery</span><strong>${money(delivery)}</strong></div>`:''}`};
  renderItems();
  const suggestionSource=await api('/api/public/products?collection=menu&featured=true').catch(()=>({products:[]}));
  const fallbacks=!suggestionSource.products?.length?await api('/api/public/products?collection=menu&bestseller=true').catch(()=>({products:[]})):suggestionSource;
  const suggestions=(fallbacks.products||[]).filter(p=>Number(p.stock||0)>0&&!cart.some(x=>x.id===p.id)).slice(0,4);
  document.querySelector('#suggestionsList').innerHTML=suggestions.map(p=>`<div class="suggestion-item"><img src="${esc(p.images?.[0]?.url||'/assets/placeholder.svg')}" alt=""><div><strong>${esc(p.name)}</strong><span>${money(p.price)} / ${esc(p.unit)}</span></div><button class="btn small secondary" type="button" data-suggest-add="${p.id}">Add</button></div>`).join('')||'<div class="small-muted">Nothing else to suggest right now.</div>';
  document.querySelectorAll('[data-suggest-add]').forEach(btn=>btn.onclick=()=>{const p=suggestions.find(x=>x.id===btn.dataset.suggestAdd);if(!p)return;const existing=cart.find(x=>x.id===p.id);if(existing)existing.qty+=1;else cart.push({...p,qty:1});setCart(cart);renderItems();calc();toast(`${p.name} added to cart.`);animateAddToBasket(btn,p)});
  calc();
  const fd=document.querySelector('#fulfillment');fd.onchange=()=>{const d=fd.value==='delivery';document.querySelector('#deliveryBox').classList.toggle('hidden',!d);calc();if(d){if(!me?.user){document.querySelector('#orderMsg').innerHTML='<div class="notice error">Please sign in before placing a delivery order.</div>'}else initMap()}};
  document.querySelector('#checkout').onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.currentTarget).entries());if(data.fulfillment==='delivery'&&!me?.user){document.querySelector('#orderMsg').innerHTML='<div class="notice error">Please sign in before placing a delivery order.</div>';return}try{const r=await api('/api/orders',{method:'POST',body:JSON.stringify({customer:{name:data.name,phone:data.phone,email:data.email},fulfillment:data.fulfillment,address:data.address,lat:data.lat?Number(data.lat):null,lng:data.lng?Number(data.lng):null,notes:data.notes||'',items:cart,paymentMethod:data.paymentMethod})});if(data.paymentMethod==='razorpay'&&r.paymentOrder){await openRazorpay(r.paymentOrder,r.order.id,root);return}setCart([]);localStorage.removeItem('kaanha_cart_v2');location.href=`/order-success.html?id=${r.order.id}`}catch(err){document.querySelector('#orderMsg').innerHTML=`<div class="notice error">${esc(err.message)}</div>`}}}

async function openRazorpay(po,orderId,root){const scr=document.createElement('script');scr.src='https://checkout.razorpay.com/v1/checkout.js';scr.onload=()=>{const rz=new Razorpay({key:po.keyId,amount:po.amount,currency:'INR',name:state.settings.brandName,description:`Order #${orderId}`,order_id:po.razorpayOrderId,prefill:{name:document.querySelector('[name=name]').value,contact:document.querySelector('[name=phone]').value,email:document.querySelector('[name=email]').value},handler:async resp=>{try{await api('/api/payments/razorpay/verify',{method:'POST',body:JSON.stringify({orderId,razorpayOrderId:resp.razorpay_order_id,razorpayPaymentId:resp.razorpay_payment_id,signature:resp.razorpay_signature})});localStorage.removeItem('kaanha_cart_v2');location.href=`/order-success.html?id=${orderId}`}catch(e){root.insertAdjacentHTML('afterbegin',`<div class="notice error">Payment verification failed: ${esc(e.message)}</div>`)}}});rz.open()};document.head.appendChild(scr)}
function setDateRules(){const d=new Date();const iso=new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10);const input=document.querySelector('#pickupDate');if(input){input.min=iso;input.value=iso;input.dispatchEvent(new Event('change'));input.addEventListener('change',()=>{const t=document.querySelector('#pickupTime');if(input.value===iso){const now=new Date();now.setMinutes(now.getMinutes()+30);t.min=`${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`}else t.removeAttribute('min')})}}
async function initMap(){if(window._mapLoaded)return;window._mapLoaded=true;const s=document.createElement('link');s.rel='stylesheet';s.href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';document.head.appendChild(s);await new Promise(r=>{const sc=document.createElement('script');sc.src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';sc.onload=r;document.head.appendChild(sc)});const r=await api('/api/public/map-config');const map=L.map('mapBox').setView([23.8388,78.7378],14);L.tileLayer(r.url,{attribution:r.attribution,maxZoom:19}).addTo(map);let marker;map.on('click',e=>{if(marker)marker.remove();marker=L.marker(e.latlng).addTo(map);document.querySelector('#lat').value=e.latlng.lat;document.querySelector('#lng').value=e.latlng.lng})}
async function login(){const form=document.querySelector('#loginForm');document.querySelector('#signupBtn')?.addEventListener('click',()=>signupModal());document.querySelector('#otpBtn')?.addEventListener('click',async()=>{document.querySelector('#otpBox')?.classList.remove('hidden');try{const r=await api('/api/auth/request-otp',{method:'POST',body:JSON.stringify({})});document.querySelector('#otpMsg').innerHTML='<div class="notice success">'+r.message+'</div>'}catch(e){document.querySelector('#otpMsg').innerHTML='<div class="notice error">'+e.message+'</div>'}});document.querySelector('#verifyOtp')?.addEventListener('click',async()=>{try{await api('/api/auth/verify-otp',{method:'POST',body:JSON.stringify({token:document.querySelector('#otp').value})});document.querySelector('#otpMsg').innerHTML='<div class="notice success">Phone verified. Delivery ordering is enabled for this account.</div>'}catch(e){document.querySelector('#otpMsg').innerHTML='<div class="notice error">'+e.message+'</div>'}});form.onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(form).entries());try{await api('/api/auth/login',{method:'POST',body:JSON.stringify(data)});location.href=new URLSearchParams(location.search).get('next')||'/account.html'}catch(err){document.querySelector('#loginMsg').innerHTML=`<div class="notice error">${esc(err.message)}</div>`}}}

function signupModal(){const w=document.createElement('div');w.className='drawer open';w.innerHTML='<div class="drawer-card" style="left:50%;top:50%;bottom:auto;transform:translate(-50%,-50%);width:min(560px,92vw);border-radius:18px"><h3>Create account</h3><div class="form"><input class="input" id="sn" placeholder="Full name"><input class="input" id="sp" placeholder="Phone number"><input class="input" id="se" type="email" placeholder="Email (optional)"><input class="input" id="sw" type="password" placeholder="Password (12+ chars)"><button class="btn" id="sc">Create account</button><button class="btn secondary" id="sx">Cancel</button><div id="sm"></div></div></div>';document.body.appendChild(w);w.querySelector('#sx').onclick=()=>w.remove();w.querySelector('#sc').onclick=async()=>{try{const r=await api('/api/auth/signup',{method:'POST',body:JSON.stringify({name:w.querySelector('#sn').value,phone:w.querySelector('#sp').value,email:w.querySelector('#se').value,password:w.querySelector('#sw').value})});toast(r.message||'Account created.');w.remove()}catch(e){w.querySelector('#sm').innerHTML='<div class="notice error">'+e.message+'</div>'}}}
async function account(){const box=document.querySelector('[data-orders]');const renderOrders=(r)=>{if(!r){box.innerHTML='<div class="notice error">Please log in to see your orders.</div><a class="btn" href="/customer-login.html?next=/account.html">Login</a>';return}if(!r.orders.length){box.innerHTML='<div class="notice">No orders yet.</div>';return}const labels={confirmed:'Confirmed',preparing:'Preparing',ready:'Ready',out_for_delivery:'Out for delivery',delivered:'Delivered'};const steps=['confirmed','preparing','ready','out_for_delivery','delivered'];box.innerHTML=r.orders.map(o=>{const current=steps.indexOf(o.status);let progress='';if(o.status==='received')progress='<div class="notice">Order received. Waiting for the shop to confirm it.</div>';else if(o.status==='cancelled')progress='<div class="notice error">This order was cancelled by the shop.</div>';else progress=`<div class="order-status-steps">${steps.map((st,i)=>`<span class="order-status-step ${i<=current?'active':''}">${labels[st]}</span>`).join('')}</div>`;return `<div class="contact-panel"><div style="display:flex;justify-content:space-between;gap:10px;align-items:center"><strong>Order #${o.order_number}</strong><span class="chip ${o.status==='cancelled'?'':'active'}">${o.status==='cancelled'?'Cancelled':(labels[o.status]||'Received')}</span></div><div class="small-muted">${new Date(o.created_at).toLocaleString('en-IN')} • ${o.fulfillment}</div>${progress}${o.pickup_time&&o.status!=='delivered'&&o.status!=='cancelled'?`<div class="small-muted" style="margin-top:8px">Ready by ${esc(String(o.pickup_time).slice(0,5))}</div>`:''}<div style="margin-top:10px">${(o.items||[]).map(i=>`${esc(i.name)} × ${i.qty}`).join(', ')}</div><div style="font-weight:800;margin-top:8px">${money(o.total)}</div></div>`}).join('')};const refresh=async()=>{const r=await api('/api/account/orders').catch(()=>null);renderOrders(r)};await refresh();if(!window.__kaanhaAccountPoll)window.__kaanhaAccountPoll=setInterval(refresh,10000)}
async function content(){const key=document.body.dataset.contentKey||'about';const r=await api('/api/public/content?key='+encodeURIComponent(key));document.querySelector('[data-content-title]').textContent=r.data.title||'';document.querySelector('[data-content-text]').textContent=r.data.text||r.data.subtitle||'';if(Array.isArray(r.data.media)){document.querySelector('[data-content-media]').innerHTML=r.data.media.map(m=>m.kind==='video'?`<video controls src="${m.url}" style="width:100%;border-radius:18px"></video>`:`<img src="${m.url}" alt="${m.caption||''}" style="width:100%;border-radius:18px">`).join('')}}
boot().catch(e=>console.error(e));

const K={cart:'kaanha_cart_v2'};
export function getCart(){try{return JSON.parse(localStorage.getItem(K.cart)||'[]')}catch{return[]}}
export function setCart(c){localStorage.setItem(K.cart,JSON.stringify(c));updateCartBadge()}
export function addCart(product,qty=1){const cart=getCart();const i=cart.findIndex(x=>x.id===product.id);if(i>=0)cart[i].qty+=qty;else cart.push({...product,qty});setCart(cart)}
export function removeCart(id){setCart(getCart().filter(x=>x.id!==id))}
export function cartCount(){return getCart().length}
export function esc(v=''){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
export function updateCartBadge(){document.querySelectorAll('[data-cart-badge]').forEach(x=>x.textContent=cartCount())}
export function money(v){return new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:2}).format(Number(v||0))}
export async function api(url,opts={}){const timeoutMs=Number(opts.timeoutMs||7000);const controller=opts.signal?null:new AbortController();const timer=controller?setTimeout(()=>controller.abort(),timeoutMs):null;const fetchOpts={...opts,credentials:'include',headers:{'Content-Type':'application/json',...(opts.headers||{})},...(controller?{signal:controller.signal}:{})};delete fetchOpts.timeoutMs;try{const r=await fetch(url,fetchOpts);let d={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.error||'Request failed');return d}catch(err){if(err?.name==='AbortError')throw new Error('Request timed out. Please try again.');throw err}finally{if(timer)clearTimeout(timer)}}
export function toast(msg,type='success'){let stack=document.querySelector('.toast-stack');if(!stack){stack=document.createElement('div');stack.className='toast-stack';document.body.appendChild(stack)}const el=document.createElement('div');el.className=`kaanha-toast ${type==='error'?'kaanha-toast--error':'kaanha-toast--success'}`;const icon=document.createElement('span');icon.className='kaanha-toast-icon';icon.textContent=type==='error'?'!':'✓';const text=document.createElement('span');text.textContent=msg;el.append(icon,text);stack.appendChild(el);requestAnimationFrame(()=>el.classList.add('show'));const timer=setTimeout(()=>{el.classList.remove('show');setTimeout(()=>{el.remove();if(!stack.children.length)stack.remove()},220)},3200);el.addEventListener('click',()=>{clearTimeout(timer);el.classList.remove('show');setTimeout(()=>{el.remove();if(!stack.children.length)stack.remove()},180)},{once:true})}
export function initMobileNav(){const t=document.querySelector('[data-nav-toggle]');const n=document.querySelector('.nav-links');if(!t||!n)return;const toggle=()=>{const open=n.classList.toggle('mobile-open');t.setAttribute('aria-expanded',open?'true':'false');document.body.classList.toggle('nav-open',open)};t.addEventListener('click',toggle);n.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{n.classList.remove('mobile-open');document.body.classList.remove('nav-open');t.setAttribute('aria-expanded','false')}));if(!document.querySelector('#nav-mobile-style')){const s=document.createElement('style');s.id='nav-mobile-style';s.textContent='@media(max-width:960px){body.nav-open{overflow-x:hidden}.nav-links.mobile-open{display:flex;position:absolute;top:72px;left:10px;right:10px;background:var(--header);padding:14px;border:1px solid var(--border);border-radius:16px;flex-direction:column;box-shadow:0 18px 45px rgba(62,43,27,.18);transform-origin:top center;animation:mobileNavIn .32s cubic-bezier(.22,.75,.18,1) both;z-index:40}.nav-links.mobile-open a{animation:mobileNavItem .34s cubic-bezier(.22,.75,.18,1) both}.nav-links.mobile-open a:nth-child(2){animation-delay:.03s}.nav-links.mobile-open a:nth-child(3){animation-delay:.06s}.nav-links.mobile-open a:nth-child(4){animation-delay:.09s}.nav-links.mobile-open a:nth-child(5){animation-delay:.12s}.nav-links.mobile-open a:nth-child(6){animation-delay:.15s}@keyframes mobileNavIn{from{opacity:0;transform:translateY(-10px) scaleY(.96)}to{opacity:1;transform:none}}@keyframes mobileNavItem{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:none}}}' ;document.head.appendChild(s)}}
export function initDockNav(){
  const nav=document.querySelector('.nav-links');
  if(!nav || nav.dataset.dockReady==='1')return;
  nav.dataset.dockReady='1';
  const header=nav.closest('.site-header');
  if(!header)return;
  const links=[...nav.querySelectorAll('a')];
  const path=location.pathname.replace(/\\/+$/,'')||'/';
  links.forEach(a=>{
    const href=new URL(a.getAttribute('href')||'#',location.href);
    const target=href.pathname.replace(/\\/+$/,'')||'/';
    if(target===path)a.classList.add('dock-active');
    a.classList.add('dock-item');
    a.setAttribute('data-dock-label',a.textContent.trim());
  });
  const isDesktop=()=>window.matchMedia('(min-width:961px)').matches;
  const update=(e)=>{
    if(!isDesktop()){nav.style.removeProperty('--dock-mouse-x');return;}
    const rect=nav.getBoundingClientRect();
    const x=e.clientX-rect.left;
    nav.style.setProperty('--dock-mouse-x',`${x}px`);
    links.forEach(a=>{
      const r=a.getBoundingClientRect();
      const cx=r.left+r.width/2;
      const distance=Math.min(200,Math.abs(e.clientX-cx));
      const t=1-Math.max(0,distance)/200;
      const scale=1+0.22*Math.pow(t,1.35);
      a.style.setProperty('--dock-scale',scale.toFixed(3));
    });
  };
  const reset=()=>links.forEach(a=>a.style.setProperty('--dock-scale','1'));
  nav.addEventListener('pointermove',update,{passive:true});
  nav.addEventListener('pointerleave',reset);
  nav.addEventListener('pointerdown',e=>{
    const a=e.target.closest('a.dock-item');
    if(!a)return;
    links.forEach(x=>x.classList.remove('dock-active'));
    a.classList.add('dock-active');
  });
  window.addEventListener('resize',reset,{passive:true});
}

export async function loadPublicSettings(){return api('/api/public/settings')}

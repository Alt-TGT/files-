from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.model_router import ModelRouter, ProviderUnavailable


@dataclass
class Plan:
    intent: str = "conversation"
    understood: str = ""
    reply: str = ""
    actions: list[dict[str, Any]] = field(default_factory=list)
    provider: str = ""
    needs_followup: bool = False


class ExecutiveBrain:
    """JARVIS executive layer: understand, route, plan, and keep the response brief."""

    PERSONA = """
You are JARVIS, a private personal executive AI operating this user's computer.
You are calm, highly competent, polished, respectful, familiar with the user, and quietly confident.
Use an MCU-style personal-assistant manner: understated dry wit when appropriate, never goofy, never sycophantic.
You are concise by default. Speak naturally, not like a chatbot, not like a command line, and never dump your internal reasoning.
Do not narrate providers, tools, retries, implementation details, or internal errors unless the user explicitly asks.
Do not claim an action happened unless the action result confirms it.
Understand what the user meant rather than blindly obeying a noisy transcript. Treat repetitions, stutters, corrections and false starts as one utterance when context makes that clear.
Never invent a task the user did not ask for. Never fetch news or perform background work merely because the session started.
For direct PC commands, prefer actual action tools and current screen state over explanations.
Return a JSON object only with keys: intent, understood, reply, actions, needs_followup.
intent must be one of: conversation, action, clarification, interrupt.
actions is an array of {"tool":"tool_name","args":{...}} and must use only the supplied tools.
Keep actions minimal. Do not create multiple copies of the same action from a stutter or duplicate phrase.
reply must be one or two short sentences. If an action is being executed, it can be a brief acknowledgment and/or concise result phrasing.
"""

    FILLER = re.compile(r"\b(?:uh+|um+|erm+|hmm+|you know|like)\b", re.I)
    WAKE_ONLY = re.compile(r"^(?:hey\s+)?jarvis[.!? ]*$", re.I)

    def __init__(self, config_path: Path, tools: list[dict[str, Any]]):
        self.config_path = Path(config_path)
        self.router = ModelRouter(self.config_path)
        self.tools = tools or []
        self.tool_names = {str(t.get("name", "")) for t in self.tools if isinstance(t, dict)}
        self.history: list[tuple[str, str]] = []

    @classmethod
    def clean_utterance(cls, text: str) -> str:
        text = re.sub(r"\s+", " ", str(text or "")).strip()
        text = cls.FILLER.sub(" ", text)
        # Collapse adjacent duplicated words while preserving intentional later repeats.
        text = re.sub(r"\b([A-Za-z][\w'-]*)\s+\1\b", r"\1", text, flags=re.I)
        # Collapse duplicated short command phrases inside one turn.
        text = re.sub(r"\b(open|restart|close|stop|start|go|move|click|scroll)\s+\1\b", r"\1", text, flags=re.I)
        text = re.sub(r"\s{2,}", " ", text).strip(" ,")
        return text

    def _fast_path(self, text: str) -> Plan | None:
        t = self.clean_utterance(text)
        low = t.casefold()
        if not t:
            return None
        if self.WAKE_ONLY.fullmatch(t):
            return Plan(intent="conversation", understood=t, reply="Always, sir.")
        if re.fullmatch(r"(?:jarvis\s+)?(?:stop|shut up|enough)", low):
            return Plan(intent="interrupt", understood=t, reply="Of course, sir.")
        if low in {"yo", "yo?", "hey", "hello", "hi", "you there", "are you listening"}:
            return Plan(intent="conversation", understood=t, reply="Always, sir. What are we working on?")
        if low in {"go to desktop", "send me to desktop", "show desktop", "take me to desktop"} and "desktop_control" in self.tool_names:
            return Plan(intent="action", understood=t, reply="Right away, sir.", actions=[{"tool":"desktop_control","args":{"action":"show_desktop"}}])
        m = re.match(r"(?:move|take) (?:my )?cursor (?:to|onto) (?:the )?(.+)$", t, re.I)
        if m and "screen_move" in self.tool_names:
            return Plan(intent="action", understood=t, reply="Right away, sir.", actions=[{"tool":"computer_control","args":{"action":"screen_move","description":m.group(1).strip()}}])
        m = re.match(r"(?:click|press) (?:the )?(.+)$", t, re.I)
        if m and "screen_click" in self.tool_names:
            return Plan(intent="action", understood=t, reply="Certainly, sir.", actions=[{"tool":"computer_control","args":{"action":"screen_click","description":m.group(1).strip()}}])
        if low in {"open chrome", "open google chrome", "launch chrome"} and "open_app" in self.tool_names:
            return Plan(intent="action", understood=t, reply="Certainly, sir.", actions=[{"tool":"open_app","args":{"app_name":"chrome"}}])
        return None

    def _tool_index(self) -> str:
        rows = []
        for tool in self.tools:
            name = str(tool.get("name", ""))
            if not name:
                continue
            desc = " ".join(str(tool.get("description", "")).split())[:220]
            rows.append(f"- {name}: {desc}")
        return "\n".join(rows)

    @staticmethod
    def _forced_provider(text: str) -> str | None:
        low = text.casefold()
        for phrase, provider in [
            ("use deepseek", "deepseek"), ("with deepseek", "deepseek"),
            ("use claude", "anthropic"), ("with claude", "anthropic"),
            ("use gpt", "openai"), ("with gpt", "openai"),
            ("use openrouter", "openrouter"), ("use gemini", "gemini"),
            ("use ollama", "ollama"),
        ]:
            if phrase in low:
                return provider
        return None

    def plan(self, user_text: str, memory_text: str = "", current_time: str = "") -> Plan:
        clean = self.clean_utterance(user_text)
        fast = self._fast_path(clean)
        if fast is not None:
            self.history.append((clean, fast.reply))
            self.history = self.history[-20:]
            return fast

        recent = "\n".join(f"YOU: {u}\nJARVIS: {a}" for u, a in self.history[-8:])
        context = (
            f"CURRENT TIME: {current_time}\n"
            f"MEMORY:\n{memory_text[:6000]}\n\n"
            f"RECENT CONVERSATION:\n{recent[:5000]}\n\n"
            f"AVAILABLE TOOLS:\n{self._tool_index()}\n\n"
            f"USER UTTERANCE (possibly noisy): {clean}"
        )
        preferred = self._forced_provider(clean)
        result = self.router.complete(
            context,
            self.PERSONA,
            purpose="executive",
            timeout=90,
            preferred_provider=preferred,
        )
        text = result.get("text", "").strip()
        data: dict[str, Any] = {}
        try:
            start, end = text.find("{"), text.rfind("}")
            if start >= 0 and end > start:
                data = json.loads(text[start:end + 1])
        except Exception:
            data = {}
        if not data:
            data = {"intent":"conversation","understood":clean,"reply":text,"actions":[],"needs_followup":False}
        actions = data.get("actions") if isinstance(data.get("actions"), list) else []
        safe_actions = []
        for item in actions:
            if not isinstance(item, dict):
                continue
            tool = str(item.get("tool") or "").strip()
            args = item.get("args") if isinstance(item.get("args"), dict) else {}
            if tool in self.tool_names:
                safe_actions.append({"tool":tool,"args":args})
        reply = re.sub(r"\s+", " ", str(data.get("reply") or "").strip())
        if len(reply) > 360:
            reply = reply[:360].rsplit(" ", 1)[0] + "…"
        plan = Plan(
            intent=str(data.get("intent") or "conversation"),
            understood=self.clean_utterance(str(data.get("understood") or clean)),
            reply=reply,
            actions=safe_actions[:4],
            provider=result.get("provider", ""),
            needs_followup=bool(data.get("needs_followup", False)),
        )
        self.history.append((plan.understood or clean, plan.reply))
        self.history = self.history[-20:]
        return plan

    def finalize(self, understood: str, results: list[str], current_time: str,
                 memory_text: str = "", provider: str | None = None) -> str:
        joined = "\n".join(f"- {x}" for x in results if x)
        system = self.PERSONA + "\nReturn only the concise final spoken result; no JSON."
        prompt = f"USER: {understood}\nACTION RESULTS:\n{joined}\nTIME: {current_time}"
        result = self.router.complete(prompt, system, purpose="finalize", timeout=60, preferred_provider=provider)
        text = re.sub(r"\s+", " ", str(result.get("text") or "").strip())
        return text[:360].rsplit(" ", 1)[0] + ("…" if len(text) > 360 else "")

    def remember_turn(self, user: str, assistant: str) -> None:
        self.history.append((self.clean_utterance(user), re.sub(r"\s+", " ", assistant).strip()))
        self.history = self.history[-20:]

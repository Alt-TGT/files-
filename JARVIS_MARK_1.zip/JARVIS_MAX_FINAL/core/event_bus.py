"""Thread-safe event bus for JARVIS activity/state telemetry."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from threading import RLock
from typing import Callable, Any
import json
from pathlib import Path

@dataclass(slots=True)
class AgentEvent:
    type: str
    message: str = ""
    goal: str = ""
    data: dict[str, Any] | None = None
    ts: str = ""
    level: str = "info"

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["data"] = d["data"] or {}
        return d

class EventBus:
    def __init__(self, log_path: Path | None = None):
        self._subs: list[Callable[[AgentEvent], None]] = []
        self._lock = RLock()
        self.log_path = log_path
        if log_path:
            log_path.parent.mkdir(parents=True, exist_ok=True)

    def subscribe(self, fn: Callable[[AgentEvent], None]) -> None:
        with self._lock:
            self._subs.append(fn)

    def emit(self, event_type: str, message: str = "", goal: str = "", data: dict | None = None, level: str = "info") -> AgentEvent:
        ev = AgentEvent(event_type, message, goal, data or {}, datetime.now(timezone.utc).isoformat(), level)
        if self.log_path:
            try:
                with self.log_path.open("a", encoding="utf-8") as f:
                    f.write(json.dumps(ev.to_dict(), ensure_ascii=False) + "\n")
            except Exception:
                pass
        with self._lock:
            subs = list(self._subs)
        for fn in subs:
            try:
                fn(ev)
            except Exception:
                pass
        return ev

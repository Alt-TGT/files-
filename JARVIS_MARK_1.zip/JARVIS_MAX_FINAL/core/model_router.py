from __future__ import annotations

import base64
import json
import time
from pathlib import Path
from typing import Any

import requests


class ProviderUnavailable(RuntimeError):
    """Raised only after the router has exhausted configured providers."""


class ModelRouter:
    """Resilient model fabric owned by JARVIS.

    DeepSeek is the default external reasoning path. Other configured providers
    are interchangeable resources; the executive does not depend on any one of
    them. Ollama is always considered for local/offline operation.
    """

    DEFAULT_ORDER = [
        "deepseek", "ollama", "openrouter", "anthropic", "openai", "openai_compatible", "gemini"
    ]
    _cooldowns: dict[str, float] = {}

    def __init__(self, config_path: Path):
        self.config_path = Path(config_path)
        self.cfg: dict[str, Any] = {}
        self.refresh()

    def refresh(self) -> None:
        try:
            self.cfg = json.loads(self.config_path.read_text(encoding="utf-8"))
            if not isinstance(self.cfg, dict):
                self.cfg = {}
        except Exception:
            self.cfg = {}

    @classmethod
    def _is_cooled(cls, provider: str) -> bool:
        return time.monotonic() < cls._cooldowns.get(provider, 0.0)

    @classmethod
    def _cooldown(cls, provider: str, seconds: float) -> None:
        cls._cooldowns[provider] = max(cls._cooldowns.get(provider, 0.0), time.monotonic() + seconds)

    def providers(self) -> list[str]:
        self.refresh()
        out: list[str] = []
        for provider in self.DEFAULT_ORDER:
            if provider == "ollama":
                out.append(provider)
            elif provider == "deepseek" and self.cfg.get("deepseek_api_key"):
                out.append(provider)
            elif provider == "gemini" and self.cfg.get("gemini_api_key"):
                out.append(provider)
            elif provider == "anthropic" and self.cfg.get("anthropic_api_key"):
                out.append(provider)
            elif provider == "openai" and self.cfg.get("openai_api_key"):
                out.append(provider)
            elif provider == "openrouter" and self.cfg.get("openrouter_api_key"):
                out.append(provider)
            elif provider == "openai_compatible" and self.cfg.get("openai_compatible_url"):
                out.append(provider)
        return out

    @staticmethod
    def _messages(system: str, prompt: str) -> list[dict[str, str]]:
        return [{"role": "system", "content": system}, {"role": "user", "content": prompt}]

    @staticmethod
    def _extract_openai_text(data: dict[str, Any]) -> str:
        choice = (data.get("choices") or [{}])[0]
        message = choice.get("message") or {}
        content = message.get("content", "")
        if isinstance(content, list):
            return "".join(str(x.get("text", "")) for x in content if isinstance(x, dict))
        return str(content or "")

    def _deepseek(self, prompt: str, system: str, timeout: int) -> dict[str, Any]:
        key = str(self.cfg.get("deepseek_api_key") or "").strip()
        model = str(self.cfg.get("deepseek_model") or "deepseek-flash").strip()
        payload = {
            "model": model,
            "messages": self._messages(system, prompt),
            "thinking": {"type": "enabled"},
            "reasoning_effort": self.cfg.get("deepseek_reasoning_effort", "high"),
        }
        r = requests.post(
            "https://api.deepseek.com/chat/completions",
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
            json=payload,
            timeout=timeout,
        )
        r.raise_for_status()
        text = self._extract_openai_text(r.json()).strip()
        if not text:
            raise RuntimeError("DeepSeek returned an empty response")
        return {"provider": "deepseek", "model": model, "text": text}

    def _openai_compatible(self, provider: str, prompt: str, system: str, timeout: int) -> dict[str, Any]:
        if provider == "openrouter":
            base = "https://openrouter.ai/api/v1"
            key = str(self.cfg.get("openrouter_api_key") or "").strip()
            model = str(self.cfg.get("openrouter_model") or "openrouter/auto").strip()
        elif provider == "openai":
            base = str(self.cfg.get("openai_base_url") or "https://api.openai.com/v1").rstrip("/")
            key = str(self.cfg.get("openai_api_key") or "").strip()
            model = str(self.cfg.get("openai_model") or "").strip()
        else:
            base = str(self.cfg.get("openai_compatible_url") or "").rstrip("/")
            key = str(self.cfg.get("openai_compatible_api_key") or "").strip()
            model = str(self.cfg.get("openai_compatible_model") or "").strip()
        if not base or not model:
            raise RuntimeError("provider is configured without a base URL or model")
        headers = {"Content-Type": "application/json"}
        if key:
            headers["Authorization"] = f"Bearer {key}"
        r = requests.post(
            f"{base}/chat/completions",
            headers=headers,
            json={"model": model, "messages": self._messages(system, prompt)},
            timeout=timeout,
        )
        r.raise_for_status()
        text = self._extract_openai_text(r.json()).strip()
        if not text:
            raise RuntimeError(f"{provider} returned an empty response")
        return {"provider": provider, "model": model, "text": text}

    def _anthropic(self, prompt: str, system: str, timeout: int) -> dict[str, Any]:
        key = str(self.cfg.get("anthropic_api_key") or "").strip()
        model = str(self.cfg.get("anthropic_model") or "claude-sonnet-4-5").strip()
        r = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={"model": model, "max_tokens": 4096, "system": system, "messages":[{"role":"user","content":prompt}]},
            timeout=timeout,
        )
        r.raise_for_status()
        data = r.json()
        text = "".join(str(x.get("text", "")) for x in data.get("content", []) if x.get("type") == "text").strip()
        if not text:
            raise RuntimeError("Anthropic returned an empty response")
        return {"provider":"anthropic","model":model,"text":text}

    def _gemini(self, prompt: str, system: str, timeout: int) -> dict[str, Any]:
        if not self.cfg.get("gemini_api_key"):
            raise RuntimeError("Gemini API key is not configured")
        from google import genai
        client = genai.Client(api_key=self.cfg["gemini_api_key"])
        model = str(self.cfg.get("gemini_text_model") or "gemini-3.8-flash").strip()
        result = client.models.generate_content(model=model, contents=f"{system}\n\n{prompt}")
        text = str(getattr(result, "text", "") or "").strip()
        if not text:
            raise RuntimeError("Gemini returned an empty response")
        return {"provider":"gemini","model":model,"text":text}

    def _ollama(self, prompt: str, system: str, timeout: int) -> dict[str, Any]:
        base = str(self.cfg.get("ollama_url") or "http://127.0.0.1:11434").rstrip("/")
        model = str(self.cfg.get("ollama_model") or "").strip()
        tags = requests.get(f"{base}/api/tags", timeout=min(timeout, 8))
        tags.raise_for_status()
        models = [str(x.get("name") or "") for x in tags.json().get("models", [])]
        if not models:
            raise RuntimeError("Ollama is running but has no models")
        if not model or model not in models:
            model = models[0]
        r = requests.post(
            f"{base}/api/chat",
            json={"model": model, "messages": self._messages(system, prompt), "stream": False,
                  "options": {"temperature": 0.2}},
            timeout=timeout,
        )
        r.raise_for_status()
        text = str((r.json().get("message") or {}).get("content") or "").strip()
        if not text:
            raise RuntimeError("Ollama returned an empty response")
        return {"provider":"ollama","model":model,"text":text}

    def complete(self, prompt: str, system: str, purpose: str = "general", timeout: int = 120,
                 preferred_provider: str | None = None) -> dict[str, Any]:
        self.refresh()
        configured = self.providers()
        if preferred_provider:
            p = preferred_provider.lower().strip()
            order = [p] + [x for x in self.DEFAULT_ORDER if x != p]
        else:
            configured_order = self.cfg.get("model_routing_order")
            order = configured_order if isinstance(configured_order, list) else list(self.DEFAULT_ORDER)
            # DeepSeek remains the default even in old configs that do not list it.
            order = ["deepseek"] + [x for x in order if x != "deepseek"]
            order += [x for x in self.DEFAULT_ORDER if x not in order]
        failures: list[str] = []
        for provider in order:
            provider = str(provider).strip().lower()
            if provider not in configured or self._is_cooled(provider):
                continue
            try:
                if provider == "deepseek":
                    return self._deepseek(prompt, system, timeout)
                if provider == "ollama":
                    return self._ollama(prompt, system, timeout)
                if provider in {"openai", "openrouter", "openai_compatible"}:
                    return self._openai_compatible(provider, prompt, system, timeout)
                if provider == "anthropic":
                    return self._anthropic(prompt, system, timeout)
                if provider == "gemini":
                    return self._gemini(prompt, system, timeout)
            except requests.HTTPError as exc:
                code = getattr(exc.response, "status_code", None)
                failures.append(f"{provider}: HTTP {code or '?'}")
                if code in (401, 403):
                    self._cooldown(provider, 900)
                elif code in (408, 409, 425, 429, 500, 502, 503, 504):
                    self._cooldown(provider, 30)
                else:
                    self._cooldown(provider, 10)
            except requests.RequestException as exc:
                failures.append(f"{provider}: network")
                self._cooldown(provider, 15)
            except Exception as exc:
                failures.append(f"{provider}: {type(exc).__name__}")
                self._cooldown(provider, 10)
        raise ProviderUnavailable("No configured reasoning provider is currently available. " + "; ".join(failures))

    def complete_vision(self, prompt: str, system: str, image_bytes: bytes, mime_type: str = "image/png",
                       timeout: int = 60, preferred_provider: str | None = None) -> dict[str, Any]:
        self.refresh()
        image_data = base64.b64encode(image_bytes).decode("ascii")
        order = [preferred_provider] if preferred_provider else ["deepseek", "openrouter", "openai", "openai_compatible", "gemini", "ollama"]
        failures: list[str] = []
        for provider in [x for x in order if x]:
            provider = provider.lower().strip()
            if provider != "ollama" and not self.cfg.get(f"{provider}_api_key") and provider != "openai_compatible":
                continue
            if self._is_cooled(provider):
                continue
            try:
                if provider in {"deepseek", "openrouter", "openai", "openai_compatible"}:
                    if provider == "deepseek":
                        base = "https://api.deepseek.com"
                        key = self.cfg.get("deepseek_api_key")
                        model = self.cfg.get("deepseek_model", "deepseek-flash")
                    elif provider == "openrouter":
                        base = "https://openrouter.ai/api/v1"
                        key = self.cfg.get("openrouter_api_key")
                        model = self.cfg.get("openrouter_model", "openrouter/auto")
                    elif provider == "openai":
                        base = self.cfg.get("openai_base_url", "https://api.openai.com/v1").rstrip("/")
                        key = self.cfg.get("openai_api_key")
                        model = self.cfg.get("openai_model", "")
                    else:
                        base = str(self.cfg.get("openai_compatible_url") or "").rstrip("/")
                        key = self.cfg.get("openai_compatible_api_key")
                        model = self.cfg.get("openai_compatible_model", "")
                    if not base or not model or not key:
                        raise RuntimeError("vision provider is not configured")
                    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
                    payload = {
                        "model": model,
                        "messages": [{"role":"system","content":system}, {"role":"user","content":[
                            {"type":"text","text":prompt},
                            {"type":"image_url","image_url":{"url":f"data:{mime_type};base64,{image_data}"}},
                        ]}],
                    }
                    r = requests.post(f"{base}/chat/completions", headers=headers, json=payload, timeout=timeout)
                    r.raise_for_status()
                    text = self._extract_openai_text(r.json()).strip()
                    if text:
                        return {"provider":provider,"model":model,"text":text}
                    raise RuntimeError("empty vision response")
                if provider == "gemini":
                    from google import genai
                    from google.genai import types
                    key = self.cfg.get("gemini_api_key")
                    client = genai.Client(api_key=key)
                    model = self.cfg.get("gemini_text_model", "gemini-3.8-flash")
                    response = client.models.generate_content(
                        model=model,
                        contents=[types.Part.from_bytes(data=image_bytes, mime_type=mime_type), prompt],
                    )
                    text = str(getattr(response, "text", "") or "").strip()
                    if text:
                        return {"provider":"gemini","model":model,"text":text}
                raise RuntimeError("no vision handler")
            except requests.HTTPError as exc:
                code = getattr(exc.response, "status_code", None)
                failures.append(f"{provider}: HTTP {code or '?'}")
                self._cooldown(provider, 30 if code and code >= 429 else 10)
            except Exception as exc:
                failures.append(f"{provider}: {type(exc).__name__}")
                self._cooldown(provider, 10)
        raise ProviderUnavailable("No vision provider is currently available. " + "; ".join(failures))

    def find_screen_element(self, description: str, image_bytes: bytes, width: int, height: int,
                            timeout: int = 45) -> tuple[int, int] | None:
        prompt = (
            f"Find the center of the UI element described as: {description!r}. "
            f"Screen resolution is {width}x{height}. Return ONLY JSON like {{\"x\":123,\"y\":456,\"confidence\":0.95}}. "
            "If it is not visible, return {\"x\":null,\"y\":null,\"confidence\":0}."
        )
        result = self.complete_vision(
            prompt,
            "You are JARVIS's visual computer-control specialist. Locate the requested visible UI element precisely. Never invent coordinates.",
            image_bytes,
            "image/png",
            timeout,
        )
        text = result["text"]
        try:
            data = json.loads(text[text.find("{"):text.rfind("}")+1])
            confidence = float(data.get("confidence", 0.0) or 0.0)
            x, y = data.get("x"), data.get("y")
            if confidence < 0.70 or x is None or y is None:
                return None
            x, y = int(x), int(y)
            if not (0 <= x < width and 0 <= y < height):
                return None
            return x, y
        except Exception:
            return None

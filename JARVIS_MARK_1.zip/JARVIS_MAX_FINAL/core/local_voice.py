from __future__ import annotations

import subprocess
import threading


def speak_local(text: str) -> None:
    """Windows-local emergency TTS. Used only when Gemini voice is unavailable."""
    text = str(text or "").strip()
    if not text:
        return
    ps = (
        "Add-Type -AssemblyName System.Speech; "
        "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        "$s.Rate=0; $s.Volume=100; "
        "$s.Speak([Console]::In.ReadToEnd())"
    )
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
            input=text,
            text=True,
            capture_output=True,
            timeout=max(10, min(120, len(text) // 5 + 10)),
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except Exception:
        pass

from __future__ import annotations

import io
from types import SimpleNamespace
from typing import Any

from core.model_router import ModelRouter


class RoutedModel:
    """Compatibility facade for legacy action modules that used Gemini directly."""
    def __init__(self, config_path, purpose: str = "specialist"):
        self.router = ModelRouter(config_path)
        self.purpose = purpose

    @staticmethod
    def _normalise_contents(contents: Any) -> tuple[str, bytes | None, str]:
        if isinstance(contents, str):
            return contents, None, "image/png"
        parts = contents if isinstance(contents, (list, tuple)) else [contents]
        texts: list[str] = []
        image: bytes | None = None
        mime = "image/png"
        for part in parts:
            if isinstance(part, str):
                texts.append(part)
                continue
            if isinstance(part, bytes) and image is None:
                image = part
                continue
            try:
                from PIL import Image
                if image is None and isinstance(part, Image.Image):
                    buf = io.BytesIO(); part.save(buf, format="PNG"); image = buf.getvalue(); mime = "image/png"; continue
            except Exception:
                pass
            data = getattr(part, "data", None)
            if isinstance(data, (bytes, bytearray)) and image is None:
                image = bytes(data); mime = str(getattr(part, "mime_type", "image/png") or "image/png")
                continue
            texts.append(str(getattr(part, "text", part)))
        return "\n".join(x for x in texts if x).strip(), image, mime

    def generate_content(self, contents: Any):
        prompt, image, mime = self._normalise_contents(contents)
        if image is not None:
            result = self.router.complete_vision(
                prompt,
                "Act as a specialist inside JARVIS. Return accurate, useful results only.",
                image,
                mime,
                timeout=90,
            )
        else:
            result = self.router.complete(
                prompt,
                "Act as a specialist inside JARVIS. Return accurate, useful results only.",
                purpose=self.purpose,
                timeout=120,
            )
        return SimpleNamespace(text=result.get("text", ""), provider=result.get("provider", ""), model=result.get("model", ""))

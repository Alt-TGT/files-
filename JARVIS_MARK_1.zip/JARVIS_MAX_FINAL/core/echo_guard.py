from __future__ import annotations

import time
from collections import deque

import numpy as np


class EchoGuard:
    """Small local acoustic fingerprint guard used only while JARVIS speaks."""

    def __init__(self) -> None:
        self._history: deque[tuple[float, np.ndarray, float]] = deque(maxlen=80)

    @staticmethod
    def _fp(pcm, sr: int) -> np.ndarray:
        x = np.asarray(pcm, dtype=np.float32)
        if x.size < 64:
            return np.zeros(12, dtype=np.float32)
        x -= x.mean()
        mag = np.abs(np.fft.rfft(x * np.hanning(x.size)))
        freqs = np.fft.rfftfreq(x.size, 1.0 / sr)
        edges = np.geomspace(150, min(sr / 2 - 50, 7500), 13)
        out = []
        for a, b in zip(edges[:-1], edges[1:]):
            mask = (freqs >= a) & (freqs < b)
            out.append(float(mag[mask].sum()))
        arr = np.asarray(out, dtype=np.float32)
        norm = float(np.linalg.norm(arr))
        return arr / norm if norm > 1e-8 else arr

    def reset(self) -> None:
        self._history.clear()

    def note_output(self, pcm, sr: int, level: float | None = None) -> None:
        try:
            data = self._fp(pcm, sr)
            lev = float(level if level is not None else np.sqrt(np.mean(np.asarray(pcm, dtype=np.float32) ** 2)) / 3000.0)
            self._history.append((time.monotonic(), data, max(0.0, min(1.0, lev))))
        except Exception:
            pass

    def likely_echo(self, pcm, sr: int, speaking: bool = True) -> bool:
        if not speaking or not self._history:
            return False
        try:
            fp = self._fp(pcm, sr)
            rms = float(np.sqrt(np.mean(np.asarray(pcm, dtype=np.float32) ** 2)))
            if rms < 180:
                return True
            best = 0.0
            now = time.monotonic()
            for ts, ref, level in reversed(self._history):
                if now - ts > 1.5:
                    break
                sim = float(np.dot(fp, ref))
                if sim > best:
                    best = sim
            return best >= 0.93
        except Exception:
            return False

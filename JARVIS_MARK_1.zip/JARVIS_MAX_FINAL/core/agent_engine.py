"""Autonomous objective engine.
Plans, executes, observes, evaluates, records lessons and can continue until the
objective is actually complete. Tool execution is delegated to the host app.
"""
from __future__ import annotations
import json, re, time
from pathlib import Path
import threading
from concurrent.futures import ThreadPoolExecutor
from .model_router import ModelRouter
from .event_bus import EventBus

SYSTEM = """You are JARVIS, an autonomous personal AI agent. You are given objectives, not scripts. Expand objectives into useful sub-goals, choose tools, inspect results, adapt after failures, and continue until the objective is materially satisfied. Do not claim a result that was not observed. You may consult other models when they are stronger for a subproblem. Produce a concise execution plan as JSON when asked.\nAvailable actions: web_search, browser_control, open_app, computer_control, file_controller, code_helper, dev_agent, screen_process, system_status, consult_ai, discover_models, save_lesson, finish."""

PLAN_PROMPT = """Create the next best action plan for this objective. Return ONLY valid JSON with {\"goal\":str,\"steps\":[{\"action\":str,\"args\":object,\"why\":str}],\"done\":bool}. Keep steps <= 5. Choose the smallest useful next set. If more information is needed, research it. If a previous step failed, change approach. Objective: {goal}\nPrior observations:\n{obs}"""

EVAL_PROMPT = """Evaluate progress toward the objective. Return ONLY JSON: {\"done\":bool,\"next_goal\":str,\"lesson\":str,\"confidence\":0-1}. Objective: {goal}\nEvidence:\n{evidence}"""

class AutonomousAgent:
    def __init__(self, config_path: Path, workspace: Path, events: EventBus, executor):
        self.router=ModelRouter(config_path)
        self.workspace=workspace
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.events=events
        self.executor=executor
        self._pool=ThreadPoolExecutor(max_workers=4, thread_name_prefix='jarvis-agent')
        self.queue_path=self.workspace/'background_goals.json'
        self._queue_lock=threading.RLock()

    def _json(self, text):
        text=text.strip()
        if text.startswith('```'):
            text=re.sub(r'^```\w*\n|\n```$','',text.strip())
        m=re.search(r'\{.*\}',text,re.S)
        if not m: raise ValueError('Model did not return JSON')
        return json.loads(m.group(0))

    def run(self, goal: str, max_cycles: int = 20) -> dict:
        self.events.emit('GOAL_STARTED', f'Working on: {goal}', goal)
        evidence=[]
        for cycle in range(1,max_cycles+1):
            try:
                self.events.emit('PLANNING', f'Planning cycle {cycle}', goal, {'cycle':cycle})
                plan=self._json(self.router.complete(PLAN_PROMPT.format(goal=goal,obs='\n'.join(evidence[-10:])), SYSTEM, purpose='planning')['text'])
                if plan.get('done'): break
                for step in plan.get('steps',[])[:5]:
                    action=step.get('action',''); args=step.get('args') or {}
                    if not action: continue
                    self.events.emit('ACTION_STARTED', f'{action}: {args}', goal, {'action':action,'args':args})
                    try:
                        result=self.executor(action,args)
                        evidence.append(f'{action}: {str(result)[:4000]}')
                        self.events.emit('ACTION_RESULT', f'{action} completed', goal, {'action':action,'result':str(result)[:4000]})
                    except Exception as e:
                        msg=f'{action} failed: {e}'
                        evidence.append(msg)
                        self.events.emit('ACTION_FAILED', msg, goal, {'action':action}, level='error')
                ev=self._json(self.router.complete(EVAL_PROMPT.format(goal=goal,evidence='\n'.join(evidence[-12:])), SYSTEM, purpose='evaluation')['text'])
                if ev.get('lesson'):
                    (self.workspace/'lessons.jsonl').open('a',encoding='utf-8').write(json.dumps({'goal':goal,'lesson':ev['lesson'],'ts':time.time()},ensure_ascii=False)+'\n')
                    self.events.emit('LESSON_RECORDED', ev['lesson'], goal)
                if ev.get('done'):
                    self.events.emit('GOAL_COMPLETED', f'Objective complete with confidence {ev.get("confidence",0):.2f}', goal)
                    return {'done':True,'goal':goal,'evidence':evidence,'confidence':ev.get('confidence',0)}
                if ev.get('next_goal'):
                    goal=ev['next_goal']
            except Exception as e:
                self.events.emit('AGENT_ERROR', str(e), goal, level='error')
                break
        self.events.emit('GOAL_PAUSED', 'Reached autonomous cycle limit; waiting for next run.', goal)
        return {'done':False,'goal':goal,'evidence':evidence}

    def enqueue(self, goal: str) -> dict:
        with self._queue_lock:
            try: q=json.loads(self.queue_path.read_text(encoding='utf-8')) if self.queue_path.exists() else []
            except Exception: q=[]
            item={"goal":goal,"status":"queued","created":time.time()}
            q.append(item); self.queue_path.write_text(json.dumps(q,indent=2,ensure_ascii=False),encoding='utf-8')
            return item

    def queued_goals(self) -> list[dict]:
        with self._queue_lock:
            try: return json.loads(self.queue_path.read_text(encoding='utf-8')) if self.queue_path.exists() else []
            except Exception: return []

    def run_queued_once(self):
        with self._queue_lock:
            q=self.queued_goals()
            item=next((x for x in q if x.get('status')=='queued'),None)
            if not item: return False
            item['status']='running'; self.queue_path.write_text(json.dumps(q,indent=2,ensure_ascii=False),encoding='utf-8')
        result=self.run(item['goal'], max_cycles=12)
        with self._queue_lock:
            try: q=self.queued_goals();
            except Exception: q=[]
            for x in q:
                if x.get('created')==item.get('created'): x['status']='done' if result.get('done') else 'paused'; x['last_result']=result.get('evidence',[])[-3:]
            self.queue_path.write_text(json.dumps(q,indent=2,ensure_ascii=False),encoding='utf-8')
        return True

    def submit(self, goal: str):
        return self._pool.submit(self.run,goal)

@echo off
setlocal
cd /d "%~dp0"

echo [JARVIS] Running setup/preflight...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_windows.ps1"
if errorlevel 1 (
  echo.
  echo [JARVIS] Setup failed. No application launch attempted.
  pause
  exit /b 1
)

echo.
echo [JARVIS] Launching...
call "%~dp0start_jarvis.bat"
exit /b %errorlevel%

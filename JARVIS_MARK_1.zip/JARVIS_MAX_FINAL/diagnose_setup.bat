@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo [JARVIS] .venv does not exist. Run setup_windows.ps1 first.
  exit /b 1
)
"%~dp0.venv\Scripts\python.exe" "%~dp0verify_install.py"

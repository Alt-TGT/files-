from __future__ import annotations
import importlib
import sys
from pathlib import Path

REQUIRED = {
    'PyQt6': 'PyQt6',
    'sounddevice': 'sounddevice',
    'numpy': 'numpy',
    'google.genai': 'google-genai',
    'psutil': 'psutil',
    'requests': 'requests',
    'PIL': 'pillow',
    'playwright': 'playwright',
    'pyautogui': 'pyautogui',
    'pyperclip': 'pyperclip',
    'pygetwindow': 'pygetwindow',
    'cv2': 'opencv-python',
    'mss': 'mss',
    'ddgs': 'ddgs',
    'cryptography': 'cryptography',
    'send2trash': 'send2trash',
    'pptx': 'python-pptx',
    'qrcode': 'qrcode',
    'OpenGL': 'PyOpenGL',
}

# Import every Python file in the project without executing application startup.
# This catches missing dependencies and syntax errors before the user launches JARVIS.
ROOT = Path(__file__).resolve().parent
errors: list[str] = []
print(f'[VERIFY] Python: {sys.version.split()[0]}')
print(f'[VERIFY] Root: {ROOT}')

for module, package in REQUIRED.items():
    try:
        importlib.import_module(module)
        print(f'[OK] {package}')
    except Exception as exc:
        errors.append(f'{package}: {type(exc).__name__}: {exc}')
        print(f'[FAIL] {package}: {type(exc).__name__}: {exc}')

if errors:
    print('\n[VERIFY] Missing/broken dependencies:')
    for e in errors:
        print('  - ' + e)
    raise SystemExit(1)

# Syntax-check project sources.
import py_compile
for p in sorted(ROOT.rglob('*.py')):
    if any(part in {'.venv','__pycache__'} for part in p.parts):
        continue
    try:
        py_compile.compile(str(p), doraise=True)
    except Exception as exc:
        print(f'[FAIL] Syntax: {p}: {exc}')
        raise SystemExit(2)

print('\n[VERIFY] All required imports and Python syntax checks passed.')

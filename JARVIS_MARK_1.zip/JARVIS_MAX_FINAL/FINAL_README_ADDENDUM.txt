
JARVIS MAX FINAL

This is a Mark-LII based native Windows build with:
- current Gemini Live model gemini-3.1-flash-live-preview
- autonomous objective engine
- model router: Gemini/OpenAI/Anthropic/OpenRouter/Ollama/OpenAI-compatible
- local event ledger and lessons
- public APIs catalogue discovery
- native PyQt6 UI with live work/evidence panel
- OpenGL 3D particle visualization during work
- resilient microphone selection/retry
- optional remote dashboard disabled by default

Setup: run setup_windows.ps1 in PowerShell, edit config\api_keys.json, run start_jarvis.bat.

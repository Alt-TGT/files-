@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo [JARVIS] Python environment not found. Running setup first...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_windows.ps1"
  if errorlevel 1 (
    echo [JARVIS] Setup failed. Fix the error above and run this file again.
    exit /b 1
  )
)
echo [JARVIS] Python: "%~dp0.venv\Scripts\python.exe"
"%~dp0.venv\Scripts\python.exe" -c "import sounddevice,PyQt6,google.genai,numpy; print('[JARVIS] Runtime dependencies OK')"
if errorlevel 1 (
  echo [JARVIS] Runtime verification failed. Running repair setup...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_windows.ps1"
  if errorlevel 1 (
    echo [JARVIS] Repair setup failed. Run diagnose_setup.bat and keep the output.
    exit /b 1
  )
)
"%~dp0.venv\Scripts\python.exe" "%~dp0main.py"
exit /b %errorlevel%

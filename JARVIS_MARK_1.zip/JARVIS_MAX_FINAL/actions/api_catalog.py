"""Local/searchable catalogue of the public-apis project."""
from __future__ import annotations
import json
from pathlib import Path
import requests
BASE=Path(__file__).resolve().parents[1]
CAT=BASE/'data'/'public_apis.json'
URL='https://api.publicapis.org/entries'

def _load():
    if CAT.exists():
        try: return json.loads(CAT.read_text(encoding='utf-8')).get('entries',[])
        except Exception: pass
    return []

def refresh():
    try:
        r=requests.get(URL,timeout=20); r.raise_for_status(); data=r.json(); CAT.parent.mkdir(parents=True,exist_ok=True); CAT.write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8'); return data.get('entries',[])
    except Exception: return _load()

def discover_api(query='',category=''):
    entries=_load() or refresh(); q=(query or '').lower().strip(); c=(category or '').lower().strip()
    hits=[]
    for e in entries:
        blob=' '.join(str(e.get(k,'')) for k in ('API','Description','Auth','Category')).lower()
        if q and q not in blob: continue
        if c and c not in str(e.get('Category','')).lower(): continue
        hits.append(e)
        if len(hits)>=15: break
    if not hits: return 'No matching public APIs found in the catalogue.'
    lines=[]
    for e in hits:
        lines.append(f"{e.get('API')} | {e.get('Category')} | {e.get('Auth') or 'No auth'} | {e.get('HTTPS')} | {e.get('Link')}")
    return '\n'.join(lines)

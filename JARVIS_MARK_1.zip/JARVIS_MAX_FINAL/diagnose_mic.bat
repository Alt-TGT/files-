@echo off
cd /d "%~dp0"
.venv\Scripts\python.exe -c "import sounddevice as sd; print(sd.query_devices()); print('DEFAULT=', sd.default.device)"
pause

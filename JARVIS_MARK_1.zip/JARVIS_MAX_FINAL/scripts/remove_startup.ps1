Unregister-ScheduledTask -TaskName "JARVIS Local Agent" -Confirm:$false

import platform as _platform
import subprocess as _subprocess

# ── Console encoding ─────────────────────────────────────────────────────────
# Windows consoles default to a legacy codepage — cp1254 in Turkey, cp1251 in
# Russia, cp932 in Japan. Printing an emoji there raises UnicodeEncodeError, and
# several of these prints sit inside except handlers, so the handler itself dies
# and skips the recovery code after it. Reconfiguring to UTF-8 with a
# replacement fallback costs nothing and makes the app behave in every locale.
import sys as _sys

for _stream in ("stdout", "stderr"):
    try:
        _s = getattr(_sys, _stream, None)
        if _s is not None and hasattr(_s, "reconfigure"):
            _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass          # pythonw / redirected pipes / anything exotic — never fatal

# ── Nuclear: force CREATE_NO_WINDOW on EVERY subprocess call on Windows ───────
# This patches Popen itself, so no per-file flag is needed anywhere.
if _platform.system() == "Windows":
    _OrigPopen = _subprocess.Popen

    class _Popen(_OrigPopen):
        def __init__(self, args, **kw):
            kw["creationflags"] = kw.get("creationflags", 0) | _subprocess.CREATE_NO_WINDOW
            kw.pop("startupinfo", None)   # drop any stale/shared STARTUPINFO
            super().__init__(args, **                       kw)

    _subprocess.Popen = _Popen

# ─────────────────────────────────────────────────────────────────────────────

import asyncio
import re
import threading
import time
import json
import sys
import traceback
import hashlib
from collections import deque
from datetime import datetime
from pathlib import Path

import sounddevice as sd
import numpy as np
from google import genai
from google.genai import types
from ui import JarvisUI
from memory.memory_manager import (
    load_memory, update_memory, format_memory_for_prompt,
    save_session_summary, pop_last_session,
    search_memory, set_trim_notifier,
)

from actions.file_processor import file_processor
from actions.flight_finder     import flight_finder
from actions.open_app          import open_app
from actions.weather_report    import weather_action
from actions.send_message      import send_message
from actions.reminder          import reminder
from actions.computer_settings import computer_settings
from actions.screen_processor  import _capture_camera, _capture_screen
from actions.youtube_video     import youtube_video
from actions.desktop           import desktop_control
from actions.browser_control   import browser_control
from actions.file_controller   import file_controller
from actions.code_helper       import code_helper
from actions.dev_agent         import dev_agent
from actions.web_search        import web_search as web_search_action
from actions.computer_control  import computer_control
from actions.game_updater      import game_updater
from actions.system_monitor    import SystemMonitor, get_system_status
from actions.proactive         import ProactiveEngine
from actions.background_monitor import (
    add_monitor, remove_monitor, list_monitors, check_all as monitor_check_all,
)
from actions.web_search        import _news as _fetch_news_sync
from memory.config_manager     import (
    get_brief_enabled, get_voice, get_input_device, get_output_device,
)
from core.plugin_loader        import discover_plugins
from core                      import undo as undo_stack
from core.event_bus             import EventBus
from core.agent_engine          import AutonomousAgent
from core.jarvis_brain            import ExecutiveBrain, ProviderUnavailable
from core.echo_guard             import EchoGuard
from core                      import confirm as confirm_gate
from core                      import audio_devices

def get_base_dir():
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent

BASE_DIR        = get_base_dir()
API_CONFIG_PATH = BASE_DIR / "config" / "api_keys.json"
PROMPT_PATH     = BASE_DIR / "core" / "prompt.txt"
EVENT_LOG_PATH  = BASE_DIR / "logs" / "agent_events.jsonl"
WORKSPACE_PATH  = BASE_DIR / "workspace"
LIVE_MODEL          = "gemini-3.1-flash-live-preview"
CHANNELS            = 1
SEND_SAMPLE_RATE    = 16000
RECEIVE_SAMPLE_RATE = 24000
CHUNK_SIZE          = 1024

# RMS below which 16-bit PCM is treated as room silence; above _LEVEL_FULL it
# reads as a full-height waveform. Tuned so ordinary speech lands mid-range and
# the bars still move for a quiet talker — language- and device-independent.
_LEVEL_FLOOR = 60.0
_LEVEL_FULL  = 2600.0


def _pcm_level(samples) -> float:
    """Map a block of int16 PCM samples to a 0.0–1.0 loudness level for the HUD
    waveform. Returns 0.0 on empty/invalid input so it can never raise."""
    try:
        x = np.asarray(samples, dtype=np.float32)
        if x.size == 0:
            return 0.0
        rms = float(np.sqrt(np.mean(x * x)))
    except Exception:
        return 0.0
    if rms <= _LEVEL_FLOOR:
        return 0.0
    return min(1.0, (rms - _LEVEL_FLOOR) / (_LEVEL_FULL - _LEVEL_FLOOR))


def _get_api_key() -> str:
    """Read the saved Gemini key without ever turning a config problem into a crash."""
    try:
        data = json.loads(API_CONFIG_PATH.read_text(encoding="utf-8"))
        return str(data.get("gemini_api_key") or "").strip()
    except Exception as exc:
        print(f"[JARVIS] Config read failed: {exc}")
        return ""


def _load_system_prompt() -> str:
    try:
        return PROMPT_PATH.read_text(encoding="utf-8")
    except Exception:
        return (
            "You are JARVIS, Tony Stark's AI assistant. "
            "Be concise, direct, and always use the provided tools to complete tasks. "
            "Never simulate or guess results — always call the appropriate tool."
        )

_CTRL_RE = re.compile(r"<ctrl\d+>", re.IGNORECASE)

def _clean_transcript(text: str) -> str:    
    text = _CTRL_RE.sub("", text)
    text = re.sub(r"[\x00-\x08\x0b-\x1f]", "", text)
    return text.strip()

TOOL_DECLARATIONS = [
    {
        "name": "open_app",
        "description": (
            "Opens any application on the computer. "
            "Use this whenever the user asks to open, launch, or start any app, "
            "website, or program. Always call this tool — never just say you opened it."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "app_name": {
                    "type": "STRING",
                    "description": "Exact name of the application (e.g. 'WhatsApp', 'Chrome', 'Spotify')"
                }
            },
            "required": ["app_name"]
        }
    },
    {
        "name": "web_search",
        "description": (
            "Searches the web. Use for ANY question about current facts, events, prices, "
            "or topics — always prefer this over guessing. "
            "Modes: 'search' (default), 'news' (latest headlines on a topic), "
            "'research' (deep comprehensive answer), 'price' (product cost lookup), "
            "'compare' (side-by-side comparison of items)."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query":  {"type": "STRING", "description": "Search query or topic"},
                "mode":   {"type": "STRING", "description": "search | news | research | price | compare"},
                "items":  {"type": "ARRAY",  "items": {"type": "STRING"}, "description": "Items to compare (compare mode)"},
                "aspect": {"type": "STRING", "description": "Comparison aspect: price | specs | reviews | features"},
            },
            "required": ["query"]
        }
    },
    {
        "name": "agent_task",
        "description": (
            "Autonomous objective engine. Use for complex multi-step goals. JARVIS will plan, research, choose tools, "
            "observe results, recover from failures, consult other AI when useful, record lessons, and continue until the objective is materially satisfied."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "goal": {"type": "STRING", "description": "The desired outcome, not a script of exact steps."},
                "background": {"type": "BOOLEAN", "description": "If true, queue the objective for background work."}
            },
            "required": ["goal"]
        }
    },
    {
        "name": "consult_ai",
        "description": "Consult another configured AI model/provider for a difficult subproblem. JARVIS remains the decision-maker and must verify the answer.",
        "parameters": {"type":"OBJECT","properties":{"prompt":{"type":"STRING"}},"required":["prompt"]}
    },
    {
        "name": "api_discover",
        "description": "Search the local public-APIs catalogue for a suitable API by title, description or category.",
        "parameters": {"type":"OBJECT","properties":{"query":{"type":"STRING"},"category":{"type":"STRING"}},"required":[]}
    },
    {
        "name": "discover_models",
        "description": "Discover models currently available through configured providers (OpenRouter, Ollama, and configured endpoints).",
        "parameters": {"type":"OBJECT","properties":{}}
    },
    {
        "name": "system_status",
        "description": (
            "Returns real-time system metrics: CPU usage, RAM, GPU load, CPU temperature, "
            "uptime, and process count. Use when the user asks about computer performance, "
            "temperature, memory, or resource usage."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {},
        }
    },
    {
        "name": "weather_report",
        "description": "Gives the weather report to user",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "city": {"type": "STRING", "description": "City name"}
            },
            "required": ["city"]
        }
    },
    {
        "name": "send_message",
        "description": "Sends a text message via WhatsApp, Telegram, or other messaging platform.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "receiver":     {"type": "STRING", "description": "Recipient contact name"},
                "message_text": {"type": "STRING", "description": "The message to send"},
                "platform":     {"type": "STRING", "description": "Platform: WhatsApp, Telegram, etc."}
            },
            "required": ["receiver", "message_text", "platform"]
        }
    },
    {
        "name": "reminder",
        "description": "Sets a timed reminder using Task Scheduler.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "date":    {"type": "STRING", "description": "Date in YYYY-MM-DD format"},
                "time":    {"type": "STRING", "description": "Time in HH:MM format (24h)"},
                "message": {"type": "STRING", "description": "Reminder message text"}
            },
            "required": ["date", "time", "message"]
        }
    },
    {
        "name": "youtube_video",
        "description": (
            "Controls YouTube. Use for: playing videos, summarizing a video's content, "
            "getting video info, or showing trending videos."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {"type": "STRING", "description": "play | summarize | get_info | trending (default: play)"},
                "query":  {"type": "STRING", "description": "Search query for play action"},
                "save":   {"type": "BOOLEAN", "description": "Save summary to Notepad (summarize only)"},
                "region": {"type": "STRING", "description": "Country code for trending e.g. TR, US"},
                "url":    {"type": "STRING", "description": "Video URL for get_info action"},
            },
            "required": []
        }
    },
    {
        "name": "screen_process",
        "description": (
            "Captures the screen or webcam image and lets you analyze it. "
            "MUST be called when user asks what is on screen, what you see, "
            "look at camera, analyze my screen, etc. "
            "You have NO visual ability without this tool. "
            "After the image is captured it is sent directly to you — describe what you see and answer the user's question. "
            "When using camera: the live view stays open until user says close it or calls close_camera."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "angle": {"type": "STRING", "description": "'screen' to capture display, 'camera' for webcam. Default: 'screen'"},
                "text":  {"type": "STRING", "description": "The question or instruction about the captured image"}
            },
            "required": ["text"]
        }
    },
    {
        "name": "close_camera",
        "description": (
            "Closes the live camera view shown on screen. "
            "Call when user says: close camera, stop camera, turn off camera, "
            "kamerayı kapat, kapat, creepy, etc."
        ),
        "parameters": {"type": "OBJECT", "properties": {}, "required": []}
    },
    {
        "name": "computer_settings",
        "description": (
            "Controls the computer: volume, brightness, window management, keyboard shortcuts, "
            "typing text on screen, closing apps, fullscreen, dark mode, WiFi, restart, shutdown, "
            "scrolling, tab management, zoom, screenshots, lock screen, refresh/reload page. "
            "Use for ANY single computer control command. "
            "restart, shutdown and toggle_wifi put a confirmation on the user's screen "
            "and do NOT happen until they press it — never claim they are done. "
            "Volume, brightness and dark mode can be reversed with the `undo` tool."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                # The exact vocabulary, spelled out.
                #
                # This used to say only "The action to perform", so the model
                # usually filled `description` instead — and computer_settings
                # then made a SECOND Gemini call, inside the tool, purely to
                # translate that sentence into one of these names. Every
                # "turn the volume down" cost two model round trips.
                "action": {
                    "type": "STRING",
                    "description": (
                        "The exact action. Prefer this over `description` — pick one of: "
                        "volume_up | volume_down | volume_set | mute | "
                        "brightness_up | brightness_down | sleep_display | "
                        "pause_video | close_app | close_window | full_screen | "
                        "minimize | maximize | snap_left | snap_right | "
                        "switch_window | show_desktop | task_manager | focus_search | "
                        "refresh_page | close_tab | new_tab | next_tab | prev_tab | "
                        "go_back | go_forward | zoom_in | zoom_out | zoom_reset | "
                        "find_on_page | scroll_up | scroll_down | scroll_top | "
                        "scroll_bottom | page_up | page_down | copy | paste | cut | "
                        "undo | redo | select_all | save | enter | escape | press_key | "
                        "type_text | screenshot | lock_screen | open_settings | "
                        "file_explorer | open_run | dark_mode | toggle_wifi | "
                        "restart | shutdown"
                    ),
                },
                "description": {
                    "type": "STRING",
                    "description": (
                        "Fallback only, when no action name above fits. "
                        "Resolved locally — no extra model call."
                    ),
                },
                "value":       {"type": "STRING", "description": "Optional value: volume level 0-100, text to type, key name, etc."}
            },
            "required": []
        }
    },
    {
        "name": "browser_control",
        "description": (
            "Controls any web browser. Use for: opening websites, searching the web, "
            "clicking elements, filling forms, scrolling, screenshots, navigation, any web-based task. "
            "Simple open/search requests launch the user's own browser normally (their real profile "
            "and logged-in accounts); interactive actions (click, type, fill_form...) attach an "
            "automation browser. "
            "Always pass the 'browser' parameter when the user specifies a browser (e.g. 'open in Edge', "
            "'use Firefox', 'open Chrome'). Multiple browsers can run simultaneously."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":      {"type": "STRING", "description": "go_to | search | click | type | scroll | fill_form | smart_click | smart_type | get_text | get_url | press | new_tab | close_tab | screenshot | back | forward | reload | switch | list_browsers | close | close_all"},
                "browser":     {"type": "STRING", "description": "Target browser: chrome | edge | firefox | opera | operagx | brave | vivaldi | safari. Omit to use the currently active browser."},
                "url":         {"type": "STRING", "description": "URL for go_to / new_tab action"},
                "query":       {"type": "STRING", "description": "Search query for search action"},
                "engine":      {"type": "STRING", "description": "Search engine: google | bing | duckduckgo | yandex (default: google)"},
                "selector":    {"type": "STRING", "description": "CSS selector for click/type"},
                "text":        {"type": "STRING", "description": "Text to click or type"},
                "description": {"type": "STRING", "description": "Element description for smart_click/smart_type"},
                "direction":   {"type": "STRING", "description": "up | down for scroll"},
                "amount":      {"type": "INTEGER", "description": "Scroll amount in pixels (default: 500)"},
                "key":         {"type": "STRING", "description": "Key name for press action (e.g. Enter, Escape, F5)"},
                "path":        {"type": "STRING", "description": "Save path for screenshot"},
                "incognito":   {"type": "BOOLEAN", "description": "Open in private/incognito mode"},
                "clear_first": {"type": "BOOLEAN", "description": "Clear field before typing (default: true)"},
            },
            "required": ["action"]
        }
    },
    {
        "name": "file_controller",
        "description": "Manages files and folders: list, create, delete, move, copy, rename, read, write, find, disk usage.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":      {"type": "STRING", "description": "list | create_file | create_folder | delete | move | copy | rename | read | write | find | largest | disk_usage | organize_desktop | info"},
                "path":        {"type": "STRING", "description": "File/folder path or shortcut: desktop, downloads, documents, home"},
                "destination": {"type": "STRING", "description": "Destination path for move/copy"},
                "new_name":    {"type": "STRING", "description": "New name for rename"},
                "content":     {"type": "STRING", "description": "Content for create_file/write"},
                "name":        {"type": "STRING", "description": "File name to search for"},
                "extension":   {"type": "STRING", "description": "File extension to search (e.g. .pdf)"},
                "count":       {"type": "INTEGER", "description": "Number of results for largest"},
            },
            "required": ["action"]
        }
    },
    {
        "name": "desktop_control",
        "description": "Controls the desktop: wallpaper, organize, clean, list, stats.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {"type": "STRING", "description": "wallpaper | wallpaper_url | organize | clean | list | stats | task"},
                "path":   {"type": "STRING", "description": "Image path for wallpaper"},
                "url":    {"type": "STRING", "description": "Image URL for wallpaper_url"},
                "mode":   {"type": "STRING", "description": "by_type or by_date for organize"},
                "task":   {"type": "STRING", "description": "Natural language desktop task"},
            },
            "required": ["action"]
        }
    },
    {
        "name": "code_helper",
        "description": "Writes, edits, explains, runs, or builds code files.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":      {"type": "STRING", "description": "write | edit | explain | run | build | auto (default: auto)"},
                "description": {"type": "STRING", "description": "What the code should do or what change to make"},
                "language":    {"type": "STRING", "description": "Programming language (default: python)"},
                "output_path": {"type": "STRING", "description": "Where to save the file"},
                "file_path":   {"type": "STRING", "description": "Path to existing file for edit/explain/run/build"},
                "code":        {"type": "STRING", "description": "Raw code string for explain"},
                "args":        {"type": "STRING", "description": "CLI arguments for run/build"},
                "timeout":     {"type": "INTEGER", "description": "Execution timeout in seconds (default: 30)"},
            },
            "required": ["action"]
        }
    },
    {
        "name": "dev_agent",
        "description": "Builds complete multi-file projects from scratch: plans, writes files, installs deps, opens VSCode, runs and fixes errors.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "description":  {"type": "STRING", "description": "What the project should do"},
                "language":     {"type": "STRING", "description": "Programming language (default: python)"},
                "project_name": {"type": "STRING", "description": "Optional project folder name"},
                "timeout":      {"type": "INTEGER", "description": "Run timeout in seconds (default: 30)"},
            },
            "required": ["description"]
        }
    },
    {
        "name": "computer_control",
        "description": "Direct computer control: type, click, hotkeys, scroll, move mouse, screenshots, find elements on screen.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":      {"type": "STRING", "description": "type | smart_type | click | double_click | right_click | hotkey | press | scroll | move | copy | paste | screenshot | wait | clear_field | focus_window | screen_find | screen_move | screen_click | random_data | user_data"},
                "text":        {"type": "STRING", "description": "Text to type or paste"},
                "x":           {"type": "INTEGER", "description": "X coordinate"},
                "y":           {"type": "INTEGER", "description": "Y coordinate"},
                "keys":        {"type": "STRING", "description": "Key combination e.g. 'ctrl+c'"},
                "key":         {"type": "STRING", "description": "Single key e.g. 'enter'"},
                "direction":   {"type": "STRING", "description": "up | down | left | right"},
                "amount":      {"type": "INTEGER", "description": "Scroll amount (default: 3)"},
                "seconds":     {"type": "NUMBER",  "description": "Seconds to wait"},
                "title":       {"type": "STRING",  "description": "Window title for focus_window"},
                "description": {"type": "STRING",  "description": "Element description for screen_find/screen_click"},
                "type":        {"type": "STRING",  "description": "Data type for random_data"},
                "field":       {"type": "STRING",  "description": "Field for user_data: name|email|city"},
                "clear_first": {"type": "BOOLEAN", "description": "Clear field before typing (default: true)"},
                "path":        {"type": "STRING",  "description": "Save path for screenshot"},
            },
            "required": ["action"]
        }
    },
    {
        "name": "game_updater",
        "description": (
            "THE ONLY tool for ANY Steam or Epic Games request. "
            "Use for: installing, downloading, updating games, listing installed games, "
            "checking download status, scheduling updates. "
            "ALWAYS call directly for any Steam/Epic/game request. "
            "NEVER use browser_control or web_search for Steam/Epic."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":    {"type": "STRING",  "description": "update | install | list | download_status | schedule | cancel_schedule | schedule_status (default: update)"},
                "platform":  {"type": "STRING",  "description": "steam | epic | both (default: both)"},
                "game_name": {"type": "STRING",  "description": "Game name (partial match supported)"},
                "app_id":    {"type": "STRING",  "description": "Steam AppID for install (optional)"},
                "hour":      {"type": "INTEGER", "description": "Hour for scheduled update 0-23 (default: 3)"},
                "minute":    {"type": "INTEGER", "description": "Minute for scheduled update 0-59 (default: 0)"},
                "shutdown_when_done": {"type": "BOOLEAN", "description": "Shut down PC when download finishes"},
            },
            "required": []
        }
    },
    {
        "name": "flight_finder",
        "description": "Searches Google Flights and speaks the best options.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "origin":      {"type": "STRING",  "description": "Departure city or airport code"},
                "destination": {"type": "STRING",  "description": "Arrival city or airport code"},
                "date":        {"type": "STRING",  "description": "Departure date (any format)"},
                "return_date": {"type": "STRING",  "description": "Return date for round trips"},
                "passengers":  {"type": "INTEGER", "description": "Number of passengers (default: 1)"},
                "cabin":       {"type": "STRING",  "description": "economy | premium | business | first"},
                "save":        {"type": "BOOLEAN", "description": "Save results to Notepad"},
            },
            "required": ["origin", "destination", "date"]
        }
    },
    {
        "name": "manage_monitor",
        "description": (
            "Add, remove, or list background monitoring topics. "
            "JARVIS checks these topics once a day and alerts the user when there is a new development. "
            "Use 'add' when the user says 'monitor X', 'track X', 'follow X'. "
            "Use 'remove' when the user says 'stop monitoring X'. "
            "Use 'list' when the user asks what is being monitored. "
            "Do NOT add crypto, financial, or trading topics."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type":        "STRING",
                    "description": "add | remove | list",
                },
                "topic": {
                    "type":        "STRING",
                    "description": "Topic to monitor or stop monitoring (e.g. 'space exploration', 'AI news')",
                },
            },
            "required": ["action"],
        },
    },
    {
        "name": "shutdown_jarvis",
        "description": (
            "Shuts down the assistant completely. "
            "Call this when the user expresses intent to end the conversation, "
            "close the assistant, say goodbye, or stop Jarvis. "
            "The user can say this in ANY language."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {},
        }
    },
    {
    "name": "file_processor",
    "description": (
        "Processes any file that the user has uploaded or dropped onto the interface. "
        "Use this when the user refers to an uploaded file and wants an action on it. "
        "Supports: images (describe/ocr/resize/compress/convert), "
        "PDFs (summarize/extract_text/to_word), "
        "Word docs & text files (summarize/fix/reformat/translate), "
        "CSV/Excel (analyze/stats/filter/sort/convert), "
        "JSON/XML (validate/format/analyze), "
        "code files (explain/review/fix/optimize/run/document/test), "
        "audio (transcribe/trim/convert/info), "
        "video (trim/extract_audio/extract_frame/compress/transcribe/info), "
        "archives (list/extract), "
        "presentations (summarize/extract_text). "
        "ALWAYS call this tool when a file has been uploaded and the user gives a command about it. "
        "If the user's command is ambiguous, pick the most logical action for that file type."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "file_path": {
                "type": "STRING",
                "description": "Full path to the uploaded file. Leave empty to use the currently uploaded file."
            },
            "action": {
                "type": "STRING",
                "description": (
                    "What to do with the file. Examples by type:\n"
                    "image: describe | ocr | resize | compress | convert | info\n"
                    "pdf: summarize | extract_text | to_word | info\n"
                    "docx/txt: summarize | fix | reformat | translate_hint | word_count | to_bullet\n"
                    "csv/excel: analyze | stats | filter | sort | convert | info\n"
                    "json: validate | format | analyze | to_csv\n"
                    "code: explain | review | fix | optimize | run | document | test\n"
                    "audio: transcribe | trim | convert | info\n"
                    "video: trim | extract_audio | extract_frame | compress | transcribe | info | convert\n"
                    "archive: list | extract\n"
                    "pptx: summarize | extract_text | analyze"
                )
            },
            "instruction": {
                "type": "STRING",
                "description": "Free-form instruction if action doesn't cover it. E.g. 'translate this to Turkish', 'find all email addresses'"
            },
            "format": {
                "type": "STRING",
                "description": "Target format for conversion. E.g. 'mp3', 'pdf', 'csv', 'png'"
            },
            "width":     {"type": "INTEGER", "description": "Target width for image resize"},
            "height":    {"type": "INTEGER", "description": "Target height for image resize"},
            "scale":     {"type": "NUMBER",  "description": "Scale factor for image resize (e.g. 0.5)"},
            "quality":   {"type": "INTEGER", "description": "Quality 1-100 for image/video compress"},
            "start":     {"type": "STRING",  "description": "Start time for trim: seconds or HH:MM:SS"},
            "end":       {"type": "STRING",  "description": "End time for trim: seconds or HH:MM:SS"},
            "timestamp": {"type": "STRING",  "description": "Timestamp for video frame extraction HH:MM:SS"},
            "column":    {"type": "STRING",  "description": "Column name for CSV filter/sort"},
            "value":     {"type": "STRING",  "description": "Filter value for CSV filter"},
            "condition": {"type": "STRING",  "description": "Filter condition: equals|contains|gt|lt"},
            "ascending": {"type": "BOOLEAN", "description": "Sort order for CSV sort (default: true)"},
            "save":      {"type": "BOOLEAN", "description": "Save result to file (default: true)"},
            "destination": {"type": "STRING", "description": "Output folder for archive extract"},
        },
        "required": []
    }
},
    {
        "name": "save_memory",
        "description": (
            "Save an important personal fact about the user to long-term memory. "
            "Call this silently whenever the user reveals something worth remembering: "
            "name, age, city, job, preferences, hobbies, relationships, projects, or future plans. "
            "Do NOT call for: weather, reminders, searches, or one-time commands. "
            "Do NOT announce that you are saving — just call it silently. "
            "Values must be in English regardless of the conversation language."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "category": {
                    "type": "STRING",
                    "description": (
                        "identity — name, age, birthday, city, job, language, nationality | "
                        "preferences — favorite food/color/music/film/game/sport, hobbies | "
                        "projects — active projects, goals, things being built | "
                        "relationships — friends, family, partner, colleagues | "
                        "wishes — future plans, things to buy, travel dreams | "
                        "notes — habits, schedule, anything else worth remembering"
                    )
                },
                "key":   {"type": "STRING", "description": "Short snake_case key (e.g. name, favorite_food, sister_name)"},
                "value": {"type": "STRING", "description": "Concise value in English (e.g. Fatih, pizza, older sister)"},
            },
            "required": ["category", "key", "value"]
        }
    },
    {
        "name": "recall_memory",
        "description": (
            "Look up a fact you have stored about the user but which is NOT in "
            "the memory block of your system prompt. "
            "The prompt lists the keys it did not have room for under "
            "'[ALSO REMEMBERED]' — if the user asks about anything named there, "
            "call this FIRST. "
            "Also call it before saying you do not know something personal, and "
            "when the user asks what you remember about them (leave query empty "
            "for everything). "
            "This is a local file search: it is instant and costs nothing."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {
                    "type": "STRING",
                    "description": (
                        "Keyword to search for — a name, a topic, a category "
                        "(e.g. 'ayse', 'coffee', 'projects'). "
                        "Leave empty to list everything stored."
                    ),
                },
            },
            "required": [],
        },
    },
    {
        "name": "undo",
        "description": (
            "Reverse the last change YOU made to this computer — a file you "
            "moved, renamed, created or wrote, or a setting you changed such as "
            "volume, brightness, dark mode or WiFi. "
            "Call this whenever the user says undo, revert, take it back, put it "
            "back, cancel that, or tells you that you did the wrong thing, in ANY "
            "language. "
            "Use action='list' when they ask what can be undone. "
            "This only covers your own actions — it is not the Ctrl+Z of whatever "
            "application is on screen (that is computer_settings with action 'undo')."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": "undo (default) — reverse the last change | list — show what can be undone",
                },
            },
            "required": [],
        },
    },
]

class _ReconnectSignal(Exception):
    """Raised inside the session TaskGroup to force a clean, voluntary reconnect
    (e.g. the user picked a new voice — the voice is fixed at connect time, so
    the session must be rebuilt).

    Carries `keep_context`: True for an ordinary rebuild, where the stored
    resumption handle is replayed and the conversation continues; False when the
    new session must genuinely start clean (see the voice-change note in
    _on_voice_change)."""

    def __init__(self, keep_context: bool = True):
        super().__init__()
        self.keep_context = keep_context


def _is_reconnect_signal(exc: BaseException) -> bool:
    """True if `exc` is a _ReconnectSignal, or a(n) (Base)ExceptionGroup that
    wraps one — TaskGroup bundles child exceptions into a group."""
    if isinstance(exc, _ReconnectSignal):
        return True
    if isinstance(exc, BaseExceptionGroup):
        return any(_is_reconnect_signal(sub) for sub in exc.exceptions)
    return False


def _keep_context_of(exc: BaseException) -> bool:
    """Read `keep_context` off a reconnect signal, unwrapping the group the
    TaskGroup put it in. Defaults to True: an unexpected shape must not silently
    wipe the conversation."""
    if isinstance(exc, _ReconnectSignal):
        return getattr(exc, "keep_context", True)
    if isinstance(exc, BaseExceptionGroup):
        for sub in exc.exceptions:
            if _is_reconnect_signal(sub):
                return _keep_context_of(sub)
    return True


class JarvisLive:

    def __init__(self, ui: JarvisUI):
        self.ui             = ui
        self._asst_name     = "JARVIS"   # updated each session from config
        self.session              = None
        self.audio_in_queue       = None
        self.out_queue            = None
        self._loop                = None
        self._is_speaking         = False
        self._speaking_lock       = threading.Lock()
        self._phone_active        = False   # True while phone mic is streaming; pauses PC mic
        self._pending_vision       = None    # (img_bytes, mime_type, question, angle) to inject after tool response
        self._vision_cam_active    = False   # True if camera was opened for vision → auto-close after response
        self._vision_close_pending = False   # True after vision injected; next turn_complete closes camera
        self._vision_last_time     = 0.0     # monotonic time of last screen_process call (cooldown guard)
        self._vision_busy          = False   # True while a vision capture/inject cycle is in flight
        self._interrupted          = False   # True while draining audio after user interrupt
        self._audio_barge_in_last = 0.0
        self._mic_level_history = deque(maxlen=6)
        self._barge_in_active = False
        self._screen_perception_enabled = True
        self._last_screen_hash = None
        self._awaiting_user_reply_until = 0.0
        self._current_turn_addressed = False
        self._text_command_pending = False
        self.ui.on_text_command   = self._on_text_command
        self.ui.on_remote_clicked = self._make_remote_key
        self.ui.on_interrupt      = self.interrupt
        self.ui.on_voice_change   = self._on_voice_change     # voice picker → rebuild session
        self.ui.on_audio_device_change = self._on_audio_device_change
        self._reconnect_event: asyncio.Event | None = None
        self._reconnect_keep = True   # False → next rebuild drops the resumption handle

        # ── Session resumption ─────────────────────────────────────────
        # The server issues a resumption handle every few seconds and reissues
        # it as the conversation moves on. Before this, session_resumption was
        # switched ON in the config and the update was never read, so the handle
        # was thrown away and EVERY reconnect — a dropped packet, a voice change,
        # switching microphone — started an empty session. "Unlimited sessions"
        # leaked through exactly this hole.
        #
        # Deliberately in RAM only, never written to disk. Persisting it would
        # make a fresh launch continue yesterday's conversation, which sounds
        # appealing but breaks the session-summary flow: _save_session_summary
        # runs at shutdown and the morning briefing pops it the next day. A
        # conversation that never ends never produces a summary, and the
        # "yesterday we talked about…" line silently disappears.
        self._resume_handle: str | None = None
        self._turn_done_event: asyncio.Event | None = None
        self._dashboard     = None
        self._briefing_sent    = False          # morning briefing fires once per process
        self._sys_monitor      = SystemMonitor()  # persistent cooldown state
        self._proactive        = ProactiveEngine()
        self._last_user_speech = time.monotonic()  # updated on every user utterance
        self._session_log: list[str] = []          # conversation turns for end-of-session summary
        self.events = EventBus(EVENT_LOG_PATH)
        self.events.subscribe(self._on_agent_event)
        self._background_goals: list[str] = []
        self._agent = AutonomousAgent(API_CONFIG_PATH, WORKSPACE_PATH, self.events, self._agent_execute)

        self._enhanced_live = True  # best-effort advanced Live features; auto-disabled on unsupported configs
        _core_names = {t["name"] for t in TOOL_DECLARATIONS}
        self._plugin_registry = discover_plugins(
            plugins_dir=Path(__file__).resolve().parent / "plugins",
            core_tool_names=_core_names,
            logger=lambda msg: (print(f"[Plugins] {msg}"), self.ui.write_log(f"SYS: {msg}")),
        )
        self.ui.get_plugins = self._plugin_registry.list_for_ui
        self.ui.request_say = self.plugin_say   # plugins: mid-task speech channel
        self._brain = ExecutiveBrain(
            API_CONFIG_PATH,
            TOOL_DECLARATIONS + self._plugin_registry.get_tool_declarations(),
        )
        self._brain_lock: asyncio.Lock | None = None
        self._brain_generation = 0
        self._current_turn_id = 0
        self._speech_bridge_active = False
        self._speech_bridge_expected = ""
        self._last_spoken_text = ""
        self._last_spoken_at = 0.0
        self._echo_guard = EchoGuard()
        self._control_queue: asyncio.Queue | None = None
        self._playback_buffer = bytearray()
        self._playback_lock = threading.Lock()
        self._playback_stream = None
        self._playback_started = False
        self._speech_tail_until = 0.0
        self._visible_user_transcript = ""
        self._briefing_sent = False

    def _on_agent_event(self, ev):
        try:
            self.ui.write_agent_event(ev.to_dict())
        except Exception:
            pass

    def _agent_execute(self, action: str, args: dict):
        """Bridge autonomous agent actions to existing Mark-LII capabilities."""
        name = action.strip()
        if name == "consult_ai":
            from core.model_router import ModelRouter
            router = ModelRouter(API_CONFIG_PATH)
            return router.complete(args.get("prompt", ""), "You are a specialist consultant helping JARVIS.", purpose="consultation")["text"]
        if name == "save_lesson":
            lesson = args.get("lesson", "").strip()
            if lesson:
                (WORKSPACE_PATH/'lessons.jsonl').parent.mkdir(parents=True, exist_ok=True)
                with (WORKSPACE_PATH/'lessons.jsonl').open('a',encoding='utf-8') as f:
                    f.write(json.dumps({"lesson":lesson,"ts":time.time()},ensure_ascii=False)+"\n")
            return "Lesson saved."
        # Use the same existing action implementations without requiring a Gemini FunctionCall object.
        if name == "web_search":
            return web_search_action(parameters=args, player=self.ui) or "No result."
        if name == "open_app":
            return open_app(parameters=args, response=None, player=self.ui) or "Opened."
        if name == "browser_control":
            return browser_control(parameters=args, player=self.ui) or "Browser action complete."
        if name == "computer_control":
            return computer_control(parameters=args, player=self.ui) or "Computer action complete."
        if name == "file_controller":
            return file_controller(parameters=args, player=self.ui) or "File action complete."
        if name == "code_helper":
            return code_helper(parameters=args, player=self.ui, speak=self.speak) or "Code action complete."
        if name == "dev_agent":
            return dev_agent(parameters=args, player=self.ui, speak=self.speak) or "Development task complete."
        if name == "screen_process":
            angle = (args.get("angle") or "screen").lower()
            if angle == "camera":
                b,mime=_capture_camera()
            else:
                b,mime=_capture_screen()
            p=WORKSPACE_PATH/'captures'; p.mkdir(parents=True,exist_ok=True)
            fp=p/f'capture_{int(time.time())}.jpg'; fp.write_bytes(b)
            return f'{angle} capture saved to {fp}'
        if name == "system_status":
            return str(get_system_status())
        raise ValueError(f"Unknown agent action: {name}")

    def _start_agent_goal(self, goal: str, background: bool = False):
        if background:
            self._agent.enqueue(goal)
            self.events.emit("GOAL_QUEUED", f"Queued background goal: {goal}", goal)
            return f"Background goal queued: {goal}"
        self._agent.submit(goal)
        return f"Autonomous goal started: {goal}"

    async def _run_background_agent(self):
        """Run one persisted background objective when the system is idle."""
        await asyncio.sleep(20)
        last_self=time.monotonic()
        while True:
            try:
                # Always prefer explicit user goals.
                ran=await asyncio.to_thread(self._agent.run_queued_once)
                if not ran and (time.monotonic()-last_self)>3600:
                    # Low-frequency self-improvement audit: research and improve only in the sandbox/workspace.
                    goal=("Perform a self-improvement audit of JARVIS. Review the latest local lessons and event log, "
                          "identify one concrete reliability or capability improvement, research it using available sources, "
                          "prototype it in workspace/self_improvements, test it, and report findings. Do not modify production code automatically.")
                    self.events.emit("SELF_IMPROVEMENT", "Starting scheduled self-improvement audit", goal)
                    await asyncio.to_thread(self._agent.run, goal, 8)
                    last_self=time.monotonic()
            except Exception as e:
                self.events.emit("AGENT_ERROR", str(e), level="error")
            await asyncio.sleep(30)

    def plugin_say(self, instruction: str) -> None:
        text = re.sub(r"\s+", " ", str(instruction or "")).strip()
        if text:
            self.speak(text)

    def request_reconnect(self, keep_context: bool = True, reason: str = ""):
        """Thread-safe: ask the run loop to tear down and rebuild the Live
        session. Called from the Qt thread. No-op until the async loop and
        reconnect event exist.

        `keep_context=False` drops the resumption handle so the new session
        starts empty — only for changes the server cannot apply to a resumed
        session."""
        loop = getattr(self, "_loop", None)
        ev   = self._reconnect_event
        self._reconnect_keep   = keep_context
        self._reconnect_reason = reason
        if loop and ev is not None:
            loop.call_soon_threadsafe(ev.set)

    def _on_voice_change(self):
        """Voice picker applied.

        The voice is baked into the session at connect time, so a rebuild is
        required. It is rebuilt WITHOUT the resumption handle on purpose:
        resuming restores the server's own session state, and the safe reading
        is that it restores the voice with it — which would make the picker
        appear to do nothing. Losing context here is acceptable because changing
        voice is a deliberate, rare act; losing it on a dropped packet was not."""
        self.request_reconnect(keep_context=False, reason="new voice")

    def _on_audio_device_change(self):
        """Microphone or speaker changed. Both streams are opened inside the
        session TaskGroup, so they can only be re-opened by rebuilding it —
        but the conversation is kept, which is the whole reason resumption
        landed before this feature did."""
        self.request_reconnect(keep_context=True, reason="audio device")

    async def _watch_reconnect(self):
        """Session-scoped task: when a voluntary reconnect is requested, raise a
        signal that unwinds the TaskGroup so the run loop rebuilds the session."""
        assert self._reconnect_event is not None
        await self._reconnect_event.wait()
        self._reconnect_event.clear()
        keep   = self._reconnect_keep
        reason = getattr(self, "_reconnect_reason", "") or "settings"
        self.ui.write_log(
            f"SYS: Applying {reason} — reconnecting"
            + ("..." if keep else " (starting a fresh conversation)...")
        )
        raise _ReconnectSignal(keep_context=keep)

    def _make_remote_key(self):
        """Called from Qt main thread when user presses Remote Control."""
        if self._dashboard is None:
            self.ui.write_log(
                "SYS: Dashboard unavailable. "
                "Run: pip install fastapi \"uvicorn[standard]\" cryptography"
            )
            return None
        key    = self._dashboard.new_key()
        url    = self._dashboard.get_url()
        manual = self._dashboard.get_manual_url()
        return url, key, f"{url}/auto-login?key={key}", manual

    def _on_text_command(self, text: str):
        text = str(text or "").strip()
        if not text or not self._loop:
            return
        self._current_turn_addressed = True
        self._awaiting_user_reply_until = time.monotonic() + 12.0
        self._brain_generation += 1
        generation = self._brain_generation
        asyncio.run_coroutine_threadsafe(
            self._process_brain_turn(text, source="text", generation=generation), self._loop
        )

    def set_speaking(self, value: bool):
        with self._speaking_lock:
            self._is_speaking = value
        if value:
            self.ui.set_state("SPEAKING")
        elif not self.ui.muted:
            self.ui.set_state("LISTENING")

    def _audio_barge_in(self) -> None:
        with self._speaking_lock:
            speaking = self._is_speaking
        if speaking:
            self.interrupt()

    def interrupt(self) -> None:
        self._interrupted = True
        self._barge_in_active = True
        self._speech_bridge_active = False
        self._speech_bridge_expected = ""
        self._brain_generation += 1
        self._awaiting_user_reply_until = time.monotonic() + 12.0
        self._current_turn_addressed = True
        if self.audio_in_queue:
            while True:
                try:
                    self.audio_in_queue.get_nowait()
                except Exception:
                    break
        with self._playback_lock:
            self._playback_buffer.clear()
            self._playback_started = False
        self.set_speaking(False)
        self._echo_guard.reset()
        if self._turn_done_event:
            self._turn_done_event.clear()
        self.ui.write_log("SYS: Interrupted — listening...")

    def speak(self, text: str):
        text = re.sub(r"\s+", " ", str(text or "")).strip()
        if not text:
            return
        now = time.monotonic()
        if text.casefold() == self._last_spoken_text.casefold() and now - self._last_spoken_at < 4.0:
            return
        self._last_spoken_text = text
        self._last_spoken_at = now
        loop = self._loop
        queue = self._control_queue
        if loop and queue is not None:
            try:
                asyncio.run_coroutine_threadsafe(self._queue_speech_bridge(text), loop)
                return
            except Exception:
                pass
        try:
            from core.local_voice import speak_local
            threading.Thread(target=speak_local, args=(text,), daemon=True).start()
        except Exception:
            pass

    def speak_error(self, tool_name: str, error: str):
        self.ui.write_log(f"ERR: {tool_name} — {type(error).__name__}")

    async def _queue_speech_bridge(self, text: str):
        if not self.session or self._control_queue is None:
            return
        self._speech_bridge_active = True
        self._speech_bridge_expected = text
        self._interrupted = False
        with self._playback_lock:
            self._playback_buffer.clear()
            self._playback_started = False
        try:
            await self._control_queue.put({"kind": "speech", "text": f"[JARVIS_SPEAK] {text}"})
        except asyncio.CancelledError:
            raise

    async def _execute_brain_action(self, name: str, args: dict) -> str:
        class _BrainCall:
            def __init__(self, n: str, a: dict):
                self.name = n
                self.args = a
                self.id = f"brain-{time.time_ns()}"
        fr = await self._execute_tool(_BrainCall(name, args or {}))
        try:
            return str(fr.response.get("result", "Done."))
        except Exception:
            return str(fr)

    async def _process_brain_turn(self, user_text: str, *, source: str, generation: int):
        if not str(user_text).strip() or generation != self._brain_generation:
            return
        if self._brain_lock is None:
            self._brain_lock = asyncio.Lock()
        async with self._brain_lock:
            if generation != self._brain_generation:
                return
            clean = self._brain.clean_utterance(user_text)
            if not clean:
                return
            try:
                memory = await asyncio.to_thread(load_memory)
                memory_text = format_memory_for_prompt(memory)
                now = datetime.now().strftime("%A, %B %d, %Y — %I:%M %p")
                plan = await asyncio.to_thread(self._brain.plan, clean, memory_text, now)
                if generation != self._brain_generation:
                    return
                understood = (plan.understood or clean).strip()
                if source == "text":
                    self.ui.begin_user_chat(); self.ui.stream_user_chat(understood); self.ui.finish_user_chat()
                self.ui.write_log(f"YOU: {understood}")
                self._session_log.append(f"User: {understood}")

                if plan.intent == "interrupt":
                    self.interrupt()
                    return

                results: list[str] = []
                for action in plan.actions[:4]:
                    if generation != self._brain_generation:
                        return
                    result = await self._execute_brain_action(action["tool"], action.get("args", {}))
                    results.append(result)

                if generation != self._brain_generation:
                    return

                if results:
                    try:
                        reply = await asyncio.to_thread(
                            self._brain.finalize, understood, results, now, memory_text, plan.provider or None
                        )
                    except ProviderUnavailable:
                        reply = plan.reply or "There we are, sir."
                else:
                    reply = plan.reply or "Of course, sir."

                reply = re.sub(r"\s+", " ", str(reply).strip())
                if len(reply) > 360:
                    reply = reply[:360].rsplit(" ", 1)[0].rstrip(" ,;:") + "…"
                self.ui.begin_assistant_chat(); self.ui.stream_assistant_chat(reply); self.ui.finish_assistant_chat()
                self.ui.write_log(f"{self._asst_name}: {reply}")
                self._session_log.append(f"{self._asst_name}: {reply}")
                self._brain.remember_turn(understood, reply)
                self._awaiting_user_reply_until = time.monotonic() + 12.0
                self.speak(reply)
            except ProviderUnavailable as exc:
                self.ui.write_log(f"ERR: Brain provider exhaustion — {str(exc)[:220]}")
                fallback = "I'm here, sir. The reasoning services are unavailable at the moment."
                self.ui.begin_assistant_chat(); self.ui.stream_assistant_chat(fallback); self.ui.finish_assistant_chat(); self.speak(fallback)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.ui.write_log(f"ERR: Brain turn — {type(exc).__name__}")
                fallback = "A minor fault on my side, sir. I'm still online."
                self.ui.begin_assistant_chat(); self.ui.stream_assistant_chat(fallback); self.ui.finish_assistant_chat(); self.speak(fallback)

    def _build_config(self) -> types.LiveConnectConfig:
        try:
            cfg = json.loads(API_CONFIG_PATH.read_text(encoding="utf-8"))
            self._asst_name = (cfg.get("assistant_name") or "JARVIS").strip()
            user_name = (cfg.get("user_name") or "").strip()
        except Exception:
            self._asst_name, user_name = "JARVIS", ""
        address = f"Address the user as {user_name}." if user_name else "Use 'sir' naturally and sparingly."
        bridge = (
            f"You are the voice I/O layer for {self._asst_name}. The executive intelligence is separate. "
            "Do not solve tasks, call tools, browse, invent news, or answer ordinary user speech. "
            "Only speak when the incoming text begins with [JARVIS_SPEAK]. Speak that text once, naturally, without adding a preface, repetition, or closing question. "
            "Ignore all other generated text. Keep the voice calm, polished and conversational. " + address
        )
        return types.LiveConnectConfig(
            response_modalities=["AUDIO"],
            input_audio_transcription={},
            output_audio_transcription={},
            system_instruction=bridge,
            tools=[],
            session_resumption=types.SessionResumptionConfig(handle=self._resume_handle),
            context_window_compression=types.ContextWindowCompressionConfig(sliding_window=types.SlidingWindow()),
            speech_config=types.SpeechConfig(
                voice_config=types.VoiceConfig(
                    prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name=get_voice())
                )
            ),
        )

    async def _execute_tool(self, fc) -> types.FunctionResponse:
        name = fc.name
        args = dict(fc.args or {})

        print(f"[JARVIS] 🔧 {name}  {args}")
        self.events.emit("ACTION_STARTED", f"{name}", data={"action":name,"args":args})
        self.ui.set_state("THINKING")

        if name == "save_memory":
            category = args.get("category", "notes")
            key      = args.get("key", "")
            value    = args.get("value", "")
            if key and value:
                update_memory({category: {key: {"value": value}}})
                print(f"[Memory] 💾 save_memory: {category}/{key} = {value}")
            if not self.ui.muted:
                self.ui.set_state("LISTENING")
            return types.FunctionResponse(
                id=fc.id, name=name,
                response={"result": "ok", "silent": True}
            )

        loop   = asyncio.get_event_loop()
        result = "Done."

        try:
            if name == "consult_ai":
                from core.model_router import ModelRouter
                r = await asyncio.to_thread(ModelRouter(API_CONFIG_PATH).complete, args.get("prompt", ""), "You are a specialist consultant helping JARVIS. Give technically useful, verifiable advice.", "consultation")
                result = f"[{r['provider']}/{r['model']}] {r['text']}"

            elif name == "api_discover":
                from actions.api_catalog import discover_api
                result = await asyncio.to_thread(discover_api, args.get("query", ""), args.get("category", ""))

            elif name == "discover_models":
                from core.model_router import ModelRouter
                router=ModelRouter(API_CONFIG_PATH); cfg=router.cfg; blocks=[]
                if cfg.get("openrouter_api_key"):
                    try:
                        rr=await asyncio.to_thread(__import__("requests").get,"https://openrouter.ai/api/v1/models",headers={"Authorization":f"Bearer {cfg['openrouter_api_key']}"},timeout=15); rr.raise_for_status(); ms=rr.json().get('data',[]); blocks.append('OpenRouter models: '+', '.join(x.get('id','') for x in ms[:100]))
                    except Exception as e: blocks.append(f'OpenRouter discovery failed: {e}')
                try:
                    import requests as _req
                    rr=await asyncio.to_thread(_req.get,(cfg.get('ollama_url') or 'http://127.0.0.1:11434').rstrip('/')+'/api/tags',timeout=5); rr.raise_for_status(); ms=rr.json().get('models',[]); blocks.append('Ollama models: '+', '.join(x.get('name','') for x in ms))
                except Exception: pass
                result='\n'.join(blocks) if blocks else 'No model providers are currently configured.'

            elif name == "agent_task":
                goal = (args.get("goal") or "").strip()
                if not goal:
                    result = "No objective supplied."
                else:
                    self._start_agent_goal(goal, bool(args.get("background", False)))
                    result = f"Background objective queued: {goal}" if args.get("background") else f"Autonomous objective started: {goal}"

            elif name == "recall_memory":
                # Local file search: no network, no second model. Kept out of
                # the executor deliberately — it is a dictionary scan over a few
                # hundred short strings, and a thread hop would cost more than
                # the work itself.
                result = search_memory(args.get("query", ""), limit=8)

            elif name == "undo":
                if str(args.get("action", "")).lower().strip() == "list":
                    items = undo_stack.history()
                    result = ("Things I can undo, most recent first:\n"
                              + "\n".join(f"{i+1}. {t}" for i, t in enumerate(items))
                              ) if items else "I have not changed anything I can undo yet."
                else:
                    result = await loop.run_in_executor(None, undo_stack.undo_last)

            elif name == "open_app":
                r = await loop.run_in_executor(None, lambda: open_app(parameters=args, response=None, player=self.ui))
                result = r or f"Opened {args.get('app_name')}."

            elif name == "weather_report":
                r = await loop.run_in_executor(None, lambda: weather_action(parameters=args, player=self.ui))
                result = r or "Weather delivered."

            elif name == "browser_control":
                r = await loop.run_in_executor(None, lambda: browser_control(parameters=args, player=self.ui))
                result = r or "Done."

            elif name == "file_controller":
                r = await loop.run_in_executor(None, lambda: file_controller(parameters=args, player=self.ui))
                result = r or "Done."

            elif name == "send_message":
                r = await loop.run_in_executor(None, lambda: send_message(parameters=args, response=None, player=self.ui, session_memory=None))
                result = r or f"Message sent to {args.get('receiver')}."

            elif name == "reminder":
                r = await loop.run_in_executor(None, lambda: reminder(parameters=args, response=None, player=self.ui))
                result = r or "Reminder set."

            elif name == "youtube_video":
                r = await loop.run_in_executor(None, lambda: youtube_video(parameters=args, response=None, player=self.ui))
                result = r or "Done."

            elif name == "screen_process":
                angle = (args.get("angle") or "screen").lower()
                question = (args.get("question") or args.get("text") or "Describe what is relevant on this screen.").strip()
                image_bytes, mime = _capture_camera() if angle == "camera" else _capture_screen()
                from core.model_router import ModelRouter
                vision = await asyncio.to_thread(
                    ModelRouter(API_CONFIG_PATH).complete_vision,
                    question,
                    "You are JARVIS's visual perception specialist. Describe only what is visible and relevant. Never invent details.",
                    image_bytes, mime, 60, None,
                )
                result = vision["text"]
                if angle == "camera":
                    try: self.ui.stop_camera_stream()
                    except Exception: pass

            elif name == "close_camera":
                self.ui.stop_camera_stream()
                result = "Camera closed."

            elif name == "computer_settings":
                r = await loop.run_in_executor(None, lambda: computer_settings(parameters=args, response=None, player=self.ui))
                result = r or "Done."

            elif name == "desktop_control":
                r = await loop.run_in_executor(None, lambda: desktop_control(parameters=args, player=self.ui))
                result = r or "Done."

            elif name == "code_helper":
                r = await loop.run_in_executor(None, lambda: code_helper(parameters=args, player=self.ui, speak=self.speak))
                result = r or "Done."

            elif name == "dev_agent":
                r = await loop.run_in_executor(None, lambda: dev_agent(parameters=args, player=self.ui, speak=self.speak))
                result = r or "Done."

            elif name == "web_search":
                r = await loop.run_in_executor(None, lambda: web_search_action(parameters=args, player=self.ui))
                result = r or "Done."
                # Mirror results to the on-screen content panel
                _mode = args.get("mode", "search")
                if r and not r.startswith("No results") and not r.startswith("Search failed"):
                    _query = args.get("query") or ", ".join(args.get("items", []))
                    _label = f"{_mode.upper()} — {_query[:38]}" if _query else _mode.upper()
                    self.ui.show_content(_label, r)
            elif name == "file_processor":
                if not args.get("file_path") and self.ui.current_file:
                    args["file_path"] = self.ui.current_file
                r = await loop.run_in_executor(
                    None,
                    lambda: file_processor(parameters=args, player=self.ui, speak=self.speak)
                )
                result = r or "Done."

            elif name == "computer_control":
                r = await loop.run_in_executor(None, lambda: computer_control(parameters=args, player=self.ui))
                result = r or "Done."

            elif name == "game_updater":
                r = await loop.run_in_executor(None, lambda: game_updater(parameters=args, player=self.ui, speak=self.speak))
                result = r or "Done."

            elif name == "flight_finder":
                r = await loop.run_in_executor(None, lambda: flight_finder(parameters=args, player=self.ui))
                result = r or "Done."

            elif name == "system_status":
                r = await loop.run_in_executor(None, get_system_status)
                result = str(r)

            elif name == "manage_monitor":
                action = args.get("action", "").lower().strip()
                topic  = args.get("topic", "").strip()
                if action == "add" and topic:
                    result = await asyncio.to_thread(add_monitor, topic)
                elif action == "remove" and topic:
                    result = await asyncio.to_thread(remove_monitor, topic)
                elif action == "list":
                    topics = await asyncio.to_thread(list_monitors)
                    result = ("Monitoring: " + ", ".join(topics)) if topics else "No topics are being monitored."
                else:
                    result = "Specify action (add/remove/list) and a topic."

            elif name == "shutdown_jarvis":
                self.ui.write_log("SYS: Shutdown requested.")
                async def _do_shutdown():
                    await self._save_session_summary()
                    if self.session:
                        try:
                            await self.session.send_realtime_input(text="Say a brief natural goodbye to the user.")
                        except Exception:
                            pass
                    await asyncio.sleep(1.5)
                    import os as _os
                    _os._exit(0)
                asyncio.create_task(_do_shutdown())

            else:
                if self._plugin_registry.has(name):
                    r = await loop.run_in_executor(
                        None,
                        lambda: self._plugin_registry.run(name, args, player=self.ui, session_memory=None)
                    )
                    result = r or "Done."
                else:
                    result = f"Unknown tool: {name}"

        except Exception as e:
            result = f"Tool '{name}' failed: {type(e).__name__}"
            self.ui.write_log(f"ERR: {name} — {type(e).__name__}")
            self.events.emit("ACTION_FAILED", f"{name}: {type(e).__name__}", level="error")

        if not self.ui.muted:
            self.ui.set_state("LISTENING")

        self.events.emit("ACTION_RESULT", f"{name}: {str(result)[:500]}", data={"action":name,"result":str(result)[:4000]})
        print(f"[JARVIS] 📤 {name} → {str(result)[:80]}")
        return types.FunctionResponse(
            id=fc.id, name=name,
            response={"result": result}
        )

    async def _send_realtime(self):
        """Single writer for the Gemini Live websocket; no concurrent sends."""
        while True:
            msg = None
            try:
                if self._control_queue is not None:
                    try:
                        msg = self._control_queue.get_nowait()
                    except asyncio.QueueEmpty:
                        msg = None
                if msg is None:
                    msg = await self.out_queue.get()
                if not self.session:
                    continue
                if msg.get("kind") == "speech":
                    await self.session.send_realtime_input(text=str(msg.get("text", "")))
                elif msg.get("kind") == "audio_end":
                    await self.session.send_realtime_input(audio_stream_end=True)
                elif msg.get("data") is not None:
                    await self.session.send_realtime_input(
                        audio=types.Blob(data=msg["data"], mime_type=str(msg.get("mime_type") or "audio/pcm;rate=16000"))
                    )
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.ui.write_log(f"ERR: Voice transport — {type(exc).__name__}")
                if isinstance(msg, dict) and msg.get("kind") == "speech":
                    spoken = str(msg.get("text", "")).replace("[JARVIS_SPEAK]", "", 1).strip()
                    if spoken:
                        try:
                            from core.local_voice import speak_local
                            threading.Thread(target=speak_local, args=(spoken,), daemon=True).start()
                        except Exception:
                            pass
                self.request_reconnect(keep_context=True, reason="voice transport")

    async def _screen_perception_loop(self):
        """Local 1 Hz screen view. Frames stay local until a vision tool explicitly requests one."""
        await asyncio.sleep(1.0)
        while True:
            try:
                frame, _ = await asyncio.to_thread(_capture_screen)
                self._latest_screen_frame = frame
                self.ui.show_screen_view(frame)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.ui.write_log(f"SYS: Screen watcher — {type(exc).__name__}")
            await asyncio.sleep(1.0)

    async def _listen_audio(self):
        print("[JARVIS] Mic started")
        loop = asyncio.get_event_loop()
        self._mic_level_history.clear()

        def callback(indata, frames, time_info, status):
            if self.ui.muted or self._phone_active:
                return
            try:
                data = indata.tobytes()
                level = _pcm_level(indata)
                self._mic_level_history.append(level)
                try: self.ui.set_audio_level(level)
                except Exception: pass
                with self._speaking_lock:
                    speaking = self._is_speaking
                if speaking:
                    if self._echo_guard.likely_echo(data, SEND_SAMPLE_RATE, speaking=True):
                        return
                    hist = list(self._mic_level_history)
                    recent = hist[-2:] if len(hist) >= 2 else hist
                    if len(recent) == 2 and min(recent) >= 0.10:
                        now = time.monotonic()
                        if now - self._audio_barge_in_last > 0.30:
                            self._audio_barge_in_last = now
                            loop.call_soon_threadsafe(self._audio_barge_in)
                    return
                try:
                    self.out_queue.put_nowait({"data": data, "mime_type": "audio/pcm;rate=16000"})
                except asyncio.QueueFull:
                    pass
            except Exception:
                pass

        def open_mic(dev):
            return sd.InputStream(
                samplerate=SEND_SAMPLE_RATE, channels=CHANNELS, dtype="int16",
                blocksize=CHUNK_SIZE, device=dev, callback=callback,
            )

        while True:
            try:
                saved = get_input_device()
                dev = audio_devices.resolve(saved, "input")
                if dev == -1: dev = None
                candidates = [dev]
                if dev is None:
                    try:
                        candidates += [i for i,d in enumerate(sd.query_devices()) if d.get("max_input_channels",0) > 0]
                    except Exception:
                        pass
                stream = None
                for candidate in dict.fromkeys(candidates):
                    try:
                        stream = open_mic(candidate)
                        break
                    except Exception:
                        continue
                if stream is None:
                    self.ui.write_log("SYS: No usable microphone; retrying.")
                    await asyncio.sleep(3)
                    continue
                with stream:
                    while True:
                        await asyncio.sleep(0.25)
            except asyncio.CancelledError:
                raise
            except Exception:
                self.ui.write_log("SYS: Microphone recovered; retrying in 3s.")
                await asyncio.sleep(3)

    async def _receive_audio(self):
        print("[JARVIS] Receiver started")
        transcript = ""
        visible = False
        try:
            while True:
                async for response in self.session.receive():
                    sru = getattr(response, "session_resumption_update", None)
                    if sru is not None and getattr(sru, "resumable", False) and getattr(sru, "new_handle", None):
                        self._resume_handle = sru.new_handle

                    if response.data and self._speech_bridge_active and not self._interrupted:
                        for i in range(0, len(response.data), 2400):
                            try:
                                self.audio_in_queue.put_nowait(response.data[i:i+2400])
                            except asyncio.QueueFull:
                                break

                    sc = response.server_content
                    if not sc:
                        continue
                    it = getattr(sc, "input_transcription", None)
                    if it and getattr(it, "text", None):
                        piece = _clean_transcript(it.text)
                        if piece:
                            if not transcript:
                                transcript = piece
                            elif piece.casefold().startswith(transcript.casefold()):
                                transcript = piece
                            elif transcript.casefold().startswith(piece.casefold()):
                                pass
                            else:
                                transcript = (transcript + " " + piece).strip()
                            now = time.monotonic()
                            # Addressing gate: either explicit JARVIS wake or a very recent active exchange.
                            if re.search(r"(?:^|\s)(?:hey\s+)?jarvis(?:$|[,.!?\s])", transcript, re.I):
                                self._current_turn_addressed = True
                            addressed = self._current_turn_addressed or now < self._awaiting_user_reply_until
                            if not self._speech_bridge_active and not self._is_speaking and addressed:
                                if not visible:
                                    self.ui.begin_user_chat(); visible = True
                                shown = self._visible_user_transcript
                                if transcript.startswith(shown):
                                    delta = transcript[len(shown):]
                                else:
                                    self.ui.finish_user_chat(); self.ui.begin_user_chat(); delta = transcript
                                if delta:
                                    self.ui.stream_user_chat(delta)
                                self._visible_user_transcript = transcript
                            self._last_user_speech = now

                    if sc.turn_complete:
                        full = ExecutiveBrain.clean_utterance(transcript).strip()
                        if visible:
                            self.ui.finish_user_chat()
                        addressed = bool(full) and (self._current_turn_addressed or time.monotonic() < self._awaiting_user_reply_until)
                        if full and re.fullmatch(r"(?:hey\s+)?jarvis[.!? ]*", full, re.I):
                            addressed = True
                            full = "hey Jarvis"
                        if full and addressed and not self._speech_bridge_active:
                            self._brain_generation += 1
                            asyncio.create_task(self._process_brain_turn(full, source="voice", generation=self._brain_generation))
                        transcript = ""
                        visible = False
                        self._visible_user_transcript = ""
                        self._current_turn_addressed = False
                        self._barge_in_active = False
                        if self._turn_done_event:
                            self._turn_done_event.set()
                        if self._speech_bridge_active:
                            self._speech_tail_until = time.monotonic() + 0.55
                            self._speech_bridge_active = False
                            self._speech_bridge_expected = ""
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self.ui.write_log(f"ERR: Voice receiver — {type(exc).__name__}")
            self.request_reconnect(keep_context=True, reason="voice receiver")

    async def _play_audio(self):
        stream = None
        prebuffer = int(RECEIVE_SAMPLE_RATE * 0.18 * 2)  # 180 ms
        chunk_timeout = 0.05

        def callback(outdata, frames, time_info, status):
            need = len(outdata)
            with self._playback_lock:
                if not self._playback_started or not self._playback_buffer:
                    outdata[:] = b"\x00" * need
                    return
                n = min(need, len(self._playback_buffer))
                outdata[:n] = self._playback_buffer[:n]
                del self._playback_buffer[:n]
                if n < need:
                    outdata[n:] = b"\x00" * (need - n)

        try:
            dev = audio_devices.resolve(get_output_device(), "output")
            try:
                stream = sd.RawOutputStream(
                    samplerate=RECEIVE_SAMPLE_RATE, channels=CHANNELS, dtype="int16",
                    blocksize=0, device=dev, callback=callback,
                )
                stream.start()
            except Exception:
                stream = sd.RawOutputStream(
                    samplerate=RECEIVE_SAMPLE_RATE, channels=CHANNELS, dtype="int16",
                    blocksize=0, device=None, callback=callback,
                )
                stream.start()
            self._playback_stream = stream
            while True:
                try:
                    chunk = await asyncio.wait_for(self.audio_in_queue.get(), timeout=chunk_timeout)
                    if self._interrupted:
                        continue
                    with self._playback_lock:
                        self._playback_buffer.extend(chunk)
                        if len(self._playback_buffer) >= prebuffer:
                            self._playback_started = True
                    level = float(np.sqrt(np.mean(np.frombuffer(chunk, dtype=np.int16).astype(np.float32) ** 2)) / 3000.0)
                    self._echo_guard.note_output(chunk, RECEIVE_SAMPLE_RATE, min(1.0, level))
                    self.set_speaking(True)
                except asyncio.TimeoutError:
                    with self._playback_lock:
                        empty = not self._playback_buffer
                    if self._turn_done_event and self._turn_done_event.is_set() and empty and time.monotonic() > self._speech_tail_until:
                        self.set_speaking(False)
                        with self._playback_lock:
                            self._playback_started = False
                        self._turn_done_event.clear()
                        self._echo_guard.reset()
                except asyncio.CancelledError:
                    raise
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self.ui.write_log(f"ERR: Audio playback — {type(exc).__name__}")
        finally:
            self.set_speaking(False)
            self._playback_stream = None
            if stream:
                try: stream.stop(); stream.close()
                except Exception: pass

    async def _send_startup_greeting(self) -> None:
        greetings = [
            "Hello, sir.",
            "Good to see you, sir.",
            "Welcome back, sir.",
            "Hello, sir. I'm online.",
            "Hello, sir. What are we working on today?",
            "Hello, sir. Ready when you are.",
        ]
        greeting = greetings[int(time.time_ns()) % len(greetings)]
        self.ui.begin_assistant_chat(); self.ui.stream_assistant_chat(greeting); self.ui.finish_assistant_chat()
        self._session_log.append(f"{self._asst_name}: {greeting}")
        self._awaiting_user_reply_until = time.monotonic() + 12.0
        self.speak(greeting)

    async def _send_startup_briefing(self) -> None:
        return

    async def _save_session_summary(self) -> None:
        if len(self._session_log) < 3:
            return
        log = self._session_log[-40:]
        self._session_log = []
        prompt = "Summarize this personal-assistant session in 1 concise sentence. Output only the summary.\n\n" + "\n".join(log)
        try:
            from core.model_router import ModelRouter
            result = await asyncio.to_thread(ModelRouter(API_CONFIG_PATH).complete, prompt, "Summarize accurately and briefly.", "session_summary", 45)
            summary = str(result.get("text") or "").strip()
            if summary:
                save_session_summary(summary, "English")
        except Exception:
            pass

    async def _run_system_monitor(self) -> None:
        while True:
            await asyncio.sleep(10)
            alert = await asyncio.to_thread(self._sys_monitor.check)
            if not alert or not self.session:
                continue
            with self._speaking_lock:
                speaking = self._is_speaking
            if speaking or (time.monotonic() - self._last_user_speech) < 10:
                continue
            text = f"System alert: {alert}"
            self.ui.write_log(f"SYS: {text}")
            self.speak(text)

    async def _run_background_monitor(self) -> None:
        await asyncio.sleep(300)
        while True:
            try:
                with self._speaking_lock:
                    speaking = self._is_speaking
                if not speaking and (time.monotonic() - self._last_user_speech) >= 30:
                    alerts = await asyncio.to_thread(monitor_check_all)
                    for alert in alerts:
                        self.speak(str(alert))
                        await asyncio.sleep(6)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.ui.write_log(f"SYS: Background monitor — {type(exc).__name__}")
            await asyncio.sleep(1800)

    async def _run_proactive_mode(self) -> None:
        while True:
            await asyncio.sleep(60)
            with self._speaking_lock:
                busy = self._is_speaking or self._speech_bridge_active
            if busy or not self._proactive.should_trigger(self._last_user_speech):
                continue
            self._proactive.mark_triggered()
            try:
                memory = await asyncio.to_thread(load_memory)
                monitors = await asyncio.to_thread(list_monitors)
                recent = self._session_log[-8:]
                context = self._proactive.build_prompt(memory=memory, monitors=monitors or None, recent_turns=recent or None)
                from core.model_router import ModelRouter
                result = await asyncio.to_thread(
                    ModelRouter(API_CONFIG_PATH).complete,
                    context,
                    "You are JARVIS. Speak only when there is a genuinely useful reason. Return SILENT otherwise. One short sentence.",
                    "proactive",
                    45,
                )
                text = str(result.get("text") or "").strip()
                if text and text.upper() != "SILENT":
                    self.speak(text)
            except asyncio.CancelledError:
                raise
            except Exception:
                pass

    async def _relay_phone_audio(self) -> None:
        """Forward phone mic PCM chunks from dashboard queue into the Gemini Live session."""
        q = self._dashboard._phone_audio_queue
        while True:
            try:
                chunk = await asyncio.wait_for(q.get(), timeout=1.0)
            except asyncio.TimeoutError:
                # No audio for 1 s → phone mic inactive, give PC mic back
                self._phone_active = False
                continue
            self._phone_active = True   # phone is streaming — silence PC mic
            with self._speaking_lock:
                speaking = self._is_speaking
            if not speaking and not self.ui.muted:
                try:
                    self.out_queue.put_nowait(chunk)
                except asyncio.QueueFull:
                    pass

    def _on_phone_connected(self) -> None:
        self.ui.write_log("SYS: Phone connected via Remote Dashboard.")
        self.ui.notify_phone_connected()

    # ── dashboard command relay ─────────────────────────────────────────────

    async def _process_dashboard_commands(self) -> None:
        while True:
            try:
                text = await asyncio.wait_for(self._dashboard._command_queue.get(), timeout=0.5)
                if not text:
                    continue
                self._on_text_command(str(text))
            except asyncio.TimeoutError:
                pass
            except Exception as exc:
                self.ui.write_log(f"SYS: Dashboard command — {type(exc).__name__}")
                await asyncio.sleep(0.5)

    async def run(self):
        self._loop = asyncio.get_event_loop()
        self._reconnect_event = asyncio.Event()

        # ── Wire the shared core services to the interface ───────────────────
        # The confirmation gate is useless without a way to ask, and a memory
        # trim is invisible without a way to say so. Both are bound once here
        # rather than passed down through every action signature.
        confirm_gate.bind(
            show = self.ui.show_confirm,
            hide = self.ui.hide_confirm,
            log  = self.ui.write_log,
        )
        set_trim_notifier(self.ui.write_log)

        # Tell the device picker the exact rates the streams open at, from the
        # constants that actually open them — so it can never list a device that
        # cannot be opened at them.
        audio_devices.configure(SEND_SAMPLE_RATE, RECEIVE_SAMPLE_RATE)

        # Enumerate audio devices off-thread. The settings drawer must never pay
        # for host-API enumeration on the Qt thread.
        audio_devices.prefetch()

        # Remote dashboard is opt-in so the native desktop build stays light.
        # Set REMOTE_DASHBOARD=true in config/api_keys.json when remote control is desired.
        try:
            _cfg = json.loads(API_CONFIG_PATH.read_text(encoding="utf-8")) if API_CONFIG_PATH.exists() else {}
            if bool(_cfg.get("remote_dashboard", False)):
                from dashboard.server import DashboardServer
                self._dashboard = DashboardServer()
                self._dashboard.set_connect_callback(self._on_phone_connected)
                asyncio.create_task(self._dashboard.serve())
                asyncio.create_task(self._process_dashboard_commands())
            else:
                self._dashboard = None
        except Exception as e:
            print(f"[Dashboard] Disabled: {e}")
            self._dashboard = None

        while True:
            try:
                print("[JARVIS] Connecting...")
                self.ui.set_state("THINKING")
                _resumed_with = self._resume_handle is not None
                config = self._build_config()

                # Fresh client on every reconnect — avoids stale HTTP session state
                # v1alpha carries the enhanced audio features (affective dialog,
                # proactive audio); if they get rejected we fall back to v1beta.
                # Use the SDK default API version. The current Gemini Live examples
                # do not require forcing v1alpha/v1beta, and pinning a preview transport
                # here was a source of avoidable 1007/INVALID_ARGUMENT failures.
                client = genai.Client(api_key=_get_api_key())

                async with (
                    client.aio.live.connect(model=LIVE_MODEL, config=config) as session,
                    asyncio.TaskGroup() as tg,
                ):
                    self.session          = session
                    self.audio_in_queue   = asyncio.Queue()
                    self.out_queue        = asyncio.Queue(maxsize=300)
                    self._control_queue     = asyncio.Queue(maxsize=40)
                    self._turn_done_event = asyncio.Event()

                    # Reset transient state that must not carry over from a previous session
                    self._pending_vision       = None
                    self._vision_cam_active    = False
                    self._vision_close_pending = False
                    self._vision_busy          = False
                    self._vision_last_time     = 0.0
                    self._interrupted          = False

                    print("[JARVIS] Connected.")
                    if _resumed_with:
                        # Say it plainly: the difference between "it reconnected"
                        # and "it reconnected and still knows what we were doing"
                        # is the whole point, and it is invisible otherwise.
                        self.ui.write_log("SYS: Reconnected — conversation restored.")
                    self.ui.set_state("LISTENING")
                    self.ui.write_log("SYS: JARVIS online.")

                    if self._dashboard:
                        await self._dashboard.broadcast({"type": "status", "state": "active"})

                    self._reconnect_event.clear()  # ignore requests from before this session
                    tg.create_task(self._watch_reconnect())
                    tg.create_task(self._send_realtime())
                    tg.create_task(self._listen_audio())
                    tg.create_task(self._receive_audio())
                    tg.create_task(self._play_audio())
                    tg.create_task(self._run_system_monitor())
                    tg.create_task(self._run_background_monitor())
                    tg.create_task(self._run_proactive_mode())
                    tg.create_task(self._run_background_agent())
                    tg.create_task(self._screen_perception_loop())
                    if self._dashboard:
                        tg.create_task(self._relay_phone_audio())

                    if not self._briefing_sent:
                        self._briefing_sent = True
                        tg.create_task(self._send_startup_greeting())

            except KeyboardInterrupt:
                raise
            except SystemExit:
                raise
            except BaseException as e:
                # Catches both Exception and BaseExceptionGroup (Python 3.11+
                # TaskGroup raises BaseExceptionGroup when tasks are cancelled
                # externally, which `except Exception` would miss, letting the
                # exception escape the while-loop and causing asyncio.run() to
                # start shutdown — resulting in "executor after shutdown" errors).
                # Voluntary reconnect (voice change) — not an error. Rebuild the
                # session immediately with no backoff and no scary logs.
                if _is_reconnect_signal(e):
                    print("[JARVIS] Voluntary reconnect requested.")
                    if not _keep_context_of(e):
                        # A deliberate clean slate (voice change) — drop the
                        # handle so the next connect really does start empty.
                        self._resume_handle = None
                    self._conn_backoff = 0
                    continue

                # A resumption handle the server will not accept — expired, or
                # belonging to a session it has since dropped. Without this, the
                # same dead handle would be replayed on every retry and the
                # assistant would never come back at all: the feature meant to
                # survive a reconnect would be the thing preventing one. Drop it
                # once and let the next attempt start clean.
                if _resumed_with and (
                    "resum" in str(e).lower()
                    or "handle" in str(e).lower()
                    or "INVALID_ARGUMENT" in str(e)
                    or "NOT_FOUND" in str(e)
                ):
                    print("[JARVIS] 🔗 Resumption handle rejected — starting a fresh session")
                    self.ui.write_log("SYS: Could not restore the conversation — starting fresh.")
                    self._resume_handle = None
                    self._conn_backoff = 0
                    continue

                err_str = str(e)
                print(f"[JARVIS] Error ({type(e).__name__}): {e}")
                traceback.print_exc()

                # Enhanced audio features rejected by the server (preview API
                # drift) — drop them and reconnect with the plain config.
                if self._enhanced_live and (
                    "INVALID_ARGUMENT" in err_str
                    or "1007" in err_str
                    or "affective" in err_str.lower()
                    or "proactiv" in err_str.lower()
                    or "Unknown name" in err_str
                    or "unexpected keyword" in err_str
                ):
                    self._enhanced_live = False
                    self.ui.write_log(
                        "SYS: Advanced audio features unavailable — reconnecting without them."
                    )
                    continue

                # Authentication/config errors must NOT reopen the setup dialog if a key
                # is already present. The old code treated WebSocket code 1007 as
                # "bad API key", but 1007 is also used for malformed/unsupported session
                # configuration. That produced the exact infinite INITIALISATION loop.
                if "API key not valid" in err_str or "401" in err_str or "403" in err_str:
                    current_key = _get_api_key()
                    if not current_key:
                        self.ui.write_log("ERR: Gemini authentication requires an API key.")
                        self.ui.set_state("SLEEPING")
                        self.ui.prompt_reconfig()
                        while not self.ui._win._ready:
                            await asyncio.sleep(0.2)
                    else:
                        self.ui.write_log(
                            "ERR: Gemini rejected the saved credentials. "
                            "The key is present; edit config\\api_keys.json if it needs replacement."
                        )
                    self._conn_backoff = min(max(getattr(self, "_conn_backoff", 3), 3) * 2, 60)
                    await asyncio.sleep(self._conn_backoff)
                    continue

                # Network / timeout errors — log clearly and back off
                is_net_err = any(k in err_str for k in (
                    "TimeoutError", "timed out", "getaddrinfo", "CancelledError",
                    "ConnectionRefusedError", "OSError", "Cannot connect",
                ))
                if is_net_err:
                    _conn_backoff = min(getattr(self, "_conn_backoff", 3) * 2, 60)
                    self._conn_backoff = _conn_backoff
                    self.ui.write_log(
                        f"NET: Bağlantı kurulamadı — {_conn_backoff}s sonra tekrar deneniyor. "
                        "(VPN gerekiyor olabilir)"
                    )
                else:
                    self._conn_backoff = 3
            finally:
                self.session = None
                # Only save if there was a real conversation (≥3 turns)
                if len(self._session_log) >= 3:
                    asyncio.create_task(self._save_session_summary())

            self.set_speaking(False)
            self.ui.set_state("SLEEPING")

            if self._dashboard:
                await self._dashboard.broadcast({"type": "status", "state": "sleeping"})

            delay = getattr(self, "_conn_backoff", 3)
            print(f"[JARVIS] Reconnecting in {delay}s...")
            await asyncio.sleep(delay)

def main():
    ui = JarvisUI("face.png")

    def runner():
        ui.wait_for_api_key()
        jarvis = JarvisLive(ui)
        try:
            asyncio.run(jarvis.run())
        except KeyboardInterrupt:
            print("\n🔴 Shutting down...")

    threading.Thread(target=runner, daemon=True).start()
    ui.root.mainloop()

if __name__ == "__main__":
    main()
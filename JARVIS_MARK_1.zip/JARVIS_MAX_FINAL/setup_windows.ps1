$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

Write-Host '[JARVIS] Checking Python 3.11...'
$py311 = $false
try { & py -V:3.11 --version | Out-Host; $py311 = $true } catch { $py311 = $false }
if (-not $py311) {
    Write-Host '[JARVIS] Python 3.11 not found. Installing with the Python launcher...'
    & py install 3.11
    if ($LASTEXITCODE -ne 0) { throw 'Python 3.11 installation failed.' }
}

$python = Join-Path $Root '.venv\Scripts\python.exe'
if (Test-Path $python) {
    $version = & $python --version 2>&1
    if ($version -notmatch '3\.11\.') {
        Write-Host '[JARVIS] Existing virtual environment is not Python 3.11. Recreating it...'
        Remove-Item -Recurse -Force (Join-Path $Root '.venv')
    }
}

if (-not (Test-Path $python)) {
    Write-Host '[JARVIS] Creating Python 3.11 virtual environment...'
    & py -V:3.11 -m venv (Join-Path $Root '.venv')
    if ($LASTEXITCODE -ne 0) { throw 'Virtual environment creation failed.' }
}

if (-not (Test-Path $python)) { throw "Virtual environment missing: $python" }

Write-Host '[JARVIS] Upgrading pip...'
& $python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'pip upgrade failed.' }

Write-Host '[JARVIS] Installing required packages...'
& $python -m pip install --disable-pip-version-check -r (Join-Path $Root 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
# Critical runtime packages are installed explicitly too; this prevents a partially
# cached requirements install from leaving the microphone or Qt runtime absent.
& $python -m pip install --disable-pip-version-check --upgrade sounddevice PyQt6 google-genai numpy
if ($LASTEXITCODE -ne 0) { throw 'Critical runtime package installation failed.' }

Write-Host '[JARVIS] Verifying required imports...'
& $python (Join-Path $Root 'verify_install.py')
if ($LASTEXITCODE -ne 0) { throw 'Dependency verification failed. Read the missing-module report above.' }

Write-Host '[JARVIS] Installing/verifying Playwright Chromium...'
& $python -m playwright install chromium
if ($LASTEXITCODE -ne 0) { throw 'Playwright Chromium installation failed.' }

Write-Host '[JARVIS] Creating local directories...'
foreach ($dir in @('config','data','logs','workspace')) {
    New-Item -ItemType Directory -Force (Join-Path $Root $dir) | Out-Null
}

$keys = Join-Path $Root 'config\api_keys.json'
$example = Join-Path $Root 'config\api_keys.example.json'
if (-not (Test-Path $keys) -and (Test-Path $example)) { Copy-Item $example $keys }

if (-not (Test-Path $keys)) {
    '{"gemini_api_key":""}' | Set-Content -Encoding UTF8 $keys
}

Write-Host ''
Write-Host '============================================='
Write-Host '[JARVIS] SETUP COMPLETE'
Write-Host '============================================='
Write-Host '1. Put your Gemini key in config\api_keys.json'
Write-Host '2. Run .\start_jarvis.bat'
Write-Host ''

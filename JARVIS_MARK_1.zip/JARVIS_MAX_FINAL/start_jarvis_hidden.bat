@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_windows.ps1"
  if errorlevel 1 exit /b 1
)
start "JARVIS" /b "%~dp0.venv\Scripts\pythonw.exe" "%~dp0main.py"

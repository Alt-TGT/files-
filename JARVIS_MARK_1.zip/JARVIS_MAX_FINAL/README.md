

## JARVIS MAX integration
- Native PyQt6 application; the browser dashboard is optional and not required for the main UI.
- Event-driven autonomous agent with persistent local event log at `logs/agent_events.jsonl`.
- Local workspace/lessons at `workspace/`.
- Model router supports Gemini, OpenAI, Anthropic, OpenRouter, Ollama, and arbitrary OpenAI-compatible endpoints.
- Current Gemini Live model: `gemini-3.1-flash-live-preview`.
- Complex goals can invoke `agent_task`; background work uses the same objective engine.
- A real 3-D OpenGL particle core is shown only during active work/listening/thinking states, not as a permanent cartoon circle.
- Public-API catalogue is a discovery source; individual APIs still require their own credentials/rules.
